var IMCAT = (function () {
  'use strict';

  /**
   * XSS 보안 필터
   * @module core/security
   */

  /**
   * 보안 유틸리티
   * @class
   * @description XSS 공격 방지, HTML 새니타이징, 경로 검증 등의 보안 기능을 제공합니다.
   * 모든 사용자 입력은 자동으로 이스케이프됩니다.
   *
   * @example
   * const safe = Security.escape('<script>alert("XSS")</script>');
   * const clean = Security.sanitize(userHtml);
   */
  class Security {
    /**
     * HTML 이스케이프
     * @param {string} str - 이스케이프할 문자열
     * @returns {string} 이스케이프된 문자열
     *
     * @example
     * Security.escape('<script>alert("XSS")</script>');
     * // '&lt;script&gt;alert("XSS")&lt;/script&gt;'
     */
    static escape(str) {
      if (typeof str !== 'string') return str;
      const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#x27;',
        '/': '&#x2F;'
      };
      return str.replace(/[&<>"'/]/g, char => map[char]);
    }

    /**
     * HTML 새니타이징 (위험한 요소 및 속성 제거)
     * @param {string} html - 새니타이징할 HTML
     * @returns {string} 새니타이징된 HTML
     *
     * @example
     * Security.sanitize('<script>alert()</script><p>안전</p>');
     * // '<p>안전</p>'
     */
    static sanitize(html) {
      if (typeof html !== 'string') return '';

      // DOMParser로 파싱
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, 'text/html');

      // 위험한 요소 제거
      this._removeDangerousElements(doc.body);

      // 위험한 속성 제거
      this._removeDangerousAttributes(doc.body);
      return doc.body.innerHTML;
    }

    /**
     * 위험한 요소 제거
     * @private
     * @param {HTMLElement} element - 대상 요소
     */
    static _removeDangerousElements(element) {
      const dangerous = ['script', 'iframe', 'object', 'embed', 'link', 'style'];
      dangerous.forEach(tag => {
        const elements = element.querySelectorAll(tag);
        elements.forEach(el => el.remove());
      });
    }

    /**
     * 위험한 속성 제거
     * @private
     * @param {HTMLElement} element - 대상 요소
     */
    static _removeDangerousAttributes(element) {
      const all = element.querySelectorAll('*');
      all.forEach(el => {
        // on* 이벤트 핸들러 제거
        Array.from(el.attributes).forEach(attr => {
          if (attr.name.startsWith('on')) {
            el.removeAttribute(attr.name);
          }

          // javascript: URL 제거
          if (attr.value && attr.value.trim().toLowerCase().startsWith('javascript:')) {
            el.removeAttribute(attr.name);
          }

          // data: URL (이미지만 허용)
          if (attr.name === 'src' || attr.name === 'href') {
            if (attr.value && attr.value.trim().toLowerCase().startsWith('data:')) {
              // 이미지 data URL만 허용
              if (!attr.value.trim().toLowerCase().startsWith('data:image/')) {
                el.removeAttribute(attr.name);
              }
            }
          }
        });
      });
    }

    /**
     * 경로 검증 (경로 순회 공격 방지)
     * @param {string} path - 검증할 경로
     * @returns {boolean} 안전한 경로 여부
     *
     * @description
     * views/ 폴더 및 그 하위 폴더의 뷰 파일만 허용합니다.
     * 경로 순회 공격(..), 절대 경로, null byte 등을 차단합니다.
     *
     * @example
     * Security.validatePath('views/home.html'); // true
     * Security.validatePath('views/products.html?id=1'); // true
     * Security.validatePath('views/admin/dashboard.html'); // true (하위 폴더)
     * Security.validatePath('views/user/profile/edit.html'); // true (깊은 하위 폴더)
     * Security.validatePath('../etc/passwd'); // false
     * Security.validatePath('/etc/passwd'); // false
     * Security.validatePath('templates/page.html'); // false (views/ 외부)
     */
    static validatePath(path) {
      if (typeof path !== 'string' || !path) return false;

      // 쿼리 스트링 분리
      const [pathOnly] = path.split('?');

      // ../ 포함 차단 (상위 디렉토리 접근)
      if (pathOnly.includes('../') || pathOnly.includes('..\\')) {
        return false;
      }

      // 절대 경로 차단 (/ 로 시작)
      if (pathOnly.startsWith('/')) {
        return false;
      }

      // views/ 폴더 및 하위 폴더만 허용 (views/로 시작하는 모든 경로)
      if (!pathOnly.startsWith('views/')) {
        return false;
      }

      // null byte 포함 차단
      if (pathOnly.includes('\0') || pathOnly.includes('%00')) {
        return false;
      }

      // URL 인코딩 우회 시도 탐지
      const decoded = decodeURIComponent(pathOnly);
      if (decoded.includes('../') || decoded.includes('..\\')) {
        return false;
      }

      // .html, .php 확장자만 허용
      if (!pathOnly.endsWith('.html') && !pathOnly.endsWith('.php')) {
        return false;
      }

      // 안전한 문자만 허용 (영문, 숫자, 하이픈, 언더스코어, 슬래시, 점)
      const safePattern = /^[a-zA-Z0-9\-_/.]+$/;
      if (!safePattern.test(pathOnly)) {
        return false;
      }

      // 경로 정규화 후 재검증
      const normalized = pathOnly.replace(/\/+/g, '/');
      if (normalized !== pathOnly) {
        return false;
      }
      return true;
    }

    /**
     * 안전한 파일명 검증
     * @param {string} filename - 검증할 파일명
     * @returns {boolean} 안전한 파일명 여부
     *
     * @example
     * Security.isSafeFilename('document.pdf'); // true
     * Security.isSafeFilename('../../../etc/passwd'); // false
     */
    static isSafeFilename(filename) {
      if (typeof filename !== 'string' || !filename) return false;

      // 경로 구분자 포함 차단
      if (filename.includes('/') || filename.includes('\\')) {
        return false;
      }

      // ..를 포함하는 파일명 차단
      if (filename.includes('..')) {
        return false;
      }

      // null byte 차단
      if (filename.includes('\0') || filename.includes('%00')) {
        return false;
      }

      // 안전한 문자만 허용
      const safePattern = /^[a-zA-Z0-9\-_.]+$/;
      if (!safePattern.test(filename)) {
        return false;
      }

      // 파일명 길이 제한 (최대 255자)
      if (filename.length > 255) {
        return false;
      }
      return true;
    }

    /**
     * URL 안전성 검증
     * @param {string} url - 검증할 URL
     * @returns {boolean} 안전한 URL 여부
     *
     * @example
     * Security.isSafeUrl('https://example.com'); // true
     * Security.isSafeUrl('javascript:alert(1)'); // false
     */
    static isSafeUrl(url) {
      if (typeof url !== 'string' || !url) return false;
      const lower = url.trim().toLowerCase();

      // javascript: 프로토콜 차단
      if (lower.startsWith('javascript:')) {
        return false;
      }

      // data: 프로토콜 차단 (이미지 제외)
      if (lower.startsWith('data:') && !lower.startsWith('data:image/')) {
        return false;
      }

      // vbscript: 프로토콜 차단
      if (lower.startsWith('vbscript:')) {
        return false;
      }

      // file: 프로토콜 차단
      if (lower.startsWith('file:')) {
        return false;
      }
      return true;
    }

    /**
     * CSS 값 새니타이징 (CSS 인젝션 방지)
     * @param {string} value - CSS 값
     * @returns {string} 새니타이징된 CSS 값
     *
     * @example
     * Security.sanitizeCSS('red'); // 'red'
     * Security.sanitizeCSS('red; background: url(javascript:...)'); // 'red'
     */
    static sanitizeCSS(value) {
      if (typeof value !== 'string') return '';

      // expression(), url(javascript:), import 등 위험한 패턴 제거
      const dangerous = [/expression\s*\(/gi, /javascript:/gi, /vbscript:/gi, /@import/gi, /behavior:/gi];
      let sanitized = value;
      dangerous.forEach(pattern => {
        sanitized = sanitized.replace(pattern, '');
      });
      return sanitized.trim();
    }

    /**
     * 파라미터 새니타이징 (SQL 인젝션, XSS 방지)
     * @param {*} value - 새니타이징할 값
     * @returns {*} 새니타이징된 값
     *
     * @example
     * Security.sanitizeParam("'; DROP TABLE users--"); // " DROP TABLE users--"
     */
    static sanitizeParam(value) {
      if (typeof value !== 'string') return value;

      // SQL 인젝션 패턴 제거
      let sanitized = value.replace(/['";\\]/g, '');

      // HTML 이스케이프
      sanitized = this.escape(sanitized);
      return sanitized;
    }
  }

  /**
   * DOM 조작 유틸리티
   * @module core/dom
   */


  /**
   * DOM Element Wrapper
   * @class
   * @description jQuery 스타일의 체이닝 가능한 DOM 조작 API를 제공하는 래퍼 클래스입니다.
   * 하나 또는 여러 개의 DOM 요소를 감싸서 편리한 메서드 체이닝을 제공합니다.
   *
   * @example
   * // jQuery 스타일 체이닝
   * new DOMElement(element)
   *   .addClass('active')
   *   .text('Hello')
   *   .on('click', handler);
   */
  class DOMElement {
    /**
     * DOMElement 생성자
     * @constructor
     * @param {HTMLElement|HTMLElement[]} elements - DOM 요소 또는 요소 배열
     *
     * @example
     * const elem = new DOMElement(document.getElementById('app'));
     *
     * @example
     * const elems = new DOMElement(document.querySelectorAll('.item'));
     */
    constructor(elements) {
      this.elements = Array.isArray(elements) ? elements : [elements];
      this.length = this.elements.length;
    }

    /**
     * 각 요소에 대해 함수 실행
     * @param {Function} callback - 콜백 함수 (element, index)
     * @returns {DOMElement} 체이닝을 위한 this
     */
    each(callback) {
      this.elements.forEach((el, index) => callback.call(el, el, index));
      return this;
    }

    /**
     * 클래스 추가
     * @param {string} className - CSS 클래스 이름
     * @returns {DOMElement}
     */
    addClass(className) {
      return this.each(el => el.classList.add(className));
    }

    /**
     * 클래스 제거
     * @param {string} className - CSS 클래스 이름
     * @returns {DOMElement}
     */
    removeClass(className) {
      return this.each(el => el.classList.remove(className));
    }

    /**
     * 클래스 토글
     * @param {string} className - CSS 클래스 이름
     * @returns {DOMElement}
     */
    toggleClass(className) {
      return this.each(el => el.classList.toggle(className));
    }

    /**
     * 클래스 포함 여부
     * @param {string} className - CSS 클래스 이름
     * @returns {boolean}
     */
    hasClass(className) {
      return this.elements.some(el => el.classList.contains(className));
    }

    /**
     * 텍스트 설정/조회
     * @param {string} [value] - 설정할 텍스트
     * @returns {string|DOMElement}
     *
     * @note textContent는 브라우저에서 자동으로 안전하게 처리됨
     * (HTML 태그가 텍스트로 표시됨, XSS 위험 없음)
     */
    text(value) {
      if (value === undefined) {
        var _this$elements$;
        return ((_this$elements$ = this.elements[0]) === null || _this$elements$ === void 0 ? void 0 : _this$elements$.textContent) || '';
      }
      // textContent는 자동으로 안전함 (HTML 파싱 안 함)
      return this.each(el => el.textContent = value);
    }

    /**
     * HTML 설정/조회 (자동 새니타이징)
     * @param {string} [value] - 설정할 HTML
     * @returns {string|DOMElement}
     */
    html(value) {
      if (value === undefined) {
        var _this$elements$2;
        return ((_this$elements$2 = this.elements[0]) === null || _this$elements$2 === void 0 ? void 0 : _this$elements$2.innerHTML) || '';
      }
      // 자동 새니타이징
      const sanitized = Security.sanitize(value);
      return this.each(el => el.innerHTML = sanitized);
    }

    /**
     * 원본 HTML 설정 (새니타이징 없음)
     * 주의: 신뢰할 수 있는 소스에서만 사용!
     * @param {string} value - HTML
     * @returns {DOMElement}
     */
    rawHtml(value) {
      return this.each(el => el.innerHTML = value);
    }

    /**
     * 속성 설정/조회 (자동 이스케이프)
     * @param {string} name - 속성 이름
     * @param {string} [value] - 속성 값
     * @returns {string|DOMElement}
     */
    attr(name, value) {
      if (value === undefined) {
        var _this$elements$3;
        return (_this$elements$3 = this.elements[0]) === null || _this$elements$3 === void 0 ? void 0 : _this$elements$3.getAttribute(name);
      }
      // 자동 이스케이프
      const escaped = Security.escape(value);
      return this.each(el => el.setAttribute(name, escaped));
    }

    /**
     * 속성 제거
     * @param {string} name - 속성 이름
     * @returns {DOMElement}
     */
    removeAttr(name) {
      return this.each(el => el.removeAttribute(name));
    }

    /**
     * 데이터 속성 설정/조회
     * @param {string} key - 데이터 키
     * @param {*} [value] - 데이터 값
     * @returns {*|DOMElement}
     */
    data(key, value) {
      if (value === undefined) {
        var _this$elements$4;
        return (_this$elements$4 = this.elements[0]) === null || _this$elements$4 === void 0 ? void 0 : _this$elements$4.dataset[key];
      }
      return this.each(el => el.dataset[key] = value);
    }

    /**
     * CSS 스타일 설정/조회
     * @param {string|Object} property - CSS 속성 이름 또는 속성 객체
     * @param {string} [value] - CSS 값
     * @returns {string|DOMElement}
     */
    css(property, value) {
      if (typeof property === 'object') {
        // 여러 속성 설정
        return this.each(el => {
          Object.entries(property).forEach(_ref => {
            let [prop, val] = _ref;
            el.style[prop] = Security.sanitizeCSS(val);
          });
        });
      }
      if (value === undefined) {
        return getComputedStyle(this.elements[0])[property];
      }

      // 위험한 CSS 값 필터링
      const sanitized = Security.sanitizeCSS(value);
      return this.each(el => el.style[property] = sanitized);
    }

    /**
     * 이벤트 리스너 추가
     * @param {string} event - 이벤트 이름
     * @param {string|Function} selector - 선택자 또는 핸들러
     * @param {Function} [handler] - 핸들러
     * @returns {DOMElement}
     *
     * @example
     * // 직접 바인딩
     * IMCAT('#button').on('click', (e) => console.log('clicked'));
     *
     * @example
     * // 이벤트 위임 (권장: 동적 요소에 유리)
     * IMCAT('#list').on('click', '.item', (e) => console.log('item clicked'));
     *
     * @performance
     * - 이벤트 위임 사용 시 메모리 효율적 (리스너 1개로 여러 요소 처리)
     * - _delegates Map으로 off() 시 정확한 cleanup 보장
     */
    on(event, selector, handler) {
      // 인자 처리
      if (typeof selector === 'function') {
        handler = selector;
        selector = null;
      }
      return this.each(el => {
        if (selector) {
          // 이벤트 위임
          const delegateHandler = e => {
            const target = e.target.closest(selector);
            if (target && el.contains(target)) {
              handler.call(target, e);
            }
          };
          el.addEventListener(event, delegateHandler);
          // 나중에 제거할 수 있도록 저장
          if (!el._delegates) el._delegates = new Map();
          if (!el._delegates.has(handler)) {
            el._delegates.set(handler, new Map());
          }
          el._delegates.get(handler).set(event, delegateHandler);
        } else {
          el.addEventListener(event, handler);
        }
      });
    }

    /**
     * 이벤트 리스너 제거
     * @param {string} event - 이벤트 이름
     * @param {Function} handler - 핸들러
     * @returns {DOMElement}
     */
    off(event, handler) {
      return this.each(el => {
        var _el$_delegates;
        if ((_el$_delegates = el._delegates) !== null && _el$_delegates !== void 0 && _el$_delegates.has(handler)) {
          const eventMap = el._delegates.get(handler);
          if (eventMap.has(event)) {
            el.removeEventListener(event, eventMap.get(event));
            eventMap.delete(event);
            if (eventMap.size === 0) {
              el._delegates.delete(handler);
            }
          }
        } else {
          el.removeEventListener(event, handler);
        }
      });
    }

    /**
     * 보이기
     * @returns {DOMElement}
     */
    show() {
      return this.each(el => el.style.display = '');
    }

    /**
     * 숨기기
     * @returns {DOMElement}
     */
    hide() {
      return this.each(el => el.style.display = 'none');
    }

    /**
     * 토글
     * @returns {DOMElement}
     */
    toggle() {
      return this.each(el => {
        el.style.display = el.style.display === 'none' ? '' : 'none';
      });
    }

    /**
     * 자식 요소 추가
     * @param {string|HTMLElement|DOMElement} content - 추가할 내용
     * @returns {DOMElement}
     */
    append(content) {
      return this.each(el => {
        if (typeof content === 'string') {
          const sanitized = Security.sanitize(content);
          el.insertAdjacentHTML('beforeend', sanitized);
        } else if (content instanceof DOMElement) {
          content.elements.forEach(child => el.appendChild(child.cloneNode(true)));
        } else if (content instanceof HTMLElement) {
          el.appendChild(content.cloneNode(true));
        }
      });
    }

    /**
     * 자식 요소 앞에 추가
     * @param {string|HTMLElement|DOMElement} content - 추가할 내용
     * @returns {DOMElement}
     */
    prepend(content) {
      return this.each(el => {
        if (typeof content === 'string') {
          const sanitized = Security.sanitize(content);
          el.insertAdjacentHTML('afterbegin', sanitized);
        } else if (content instanceof DOMElement) {
          content.elements.forEach(child => el.insertBefore(child.cloneNode(true), el.firstChild));
        } else if (content instanceof HTMLElement) {
          el.insertBefore(content.cloneNode(true), el.firstChild);
        }
      });
    }

    /**
     * 부모 요소에 추가
     * @param {string|HTMLElement} parent - 부모 선택자 또는 요소
     * @returns {DOMElement}
     */
    appendTo(parent) {
      const parentEl = typeof parent === 'string' ? document.querySelector(parent) : parent;
      if (parentEl) {
        this.elements.forEach(el => parentEl.appendChild(el));
      }
      return this;
    }

    /**
     * 요소 제거
     * @returns {DOMElement}
     */
    remove() {
      return this.each(el => el.remove());
    }

    /**
     * 내용 비우기
     * @returns {DOMElement}
     */
    empty() {
      return this.each(el => el.innerHTML = '');
    }

    /**
     * 하위 요소 검색
     * @param {string} selector - CSS 선택자
     * @returns {DOMElement}
     */
    find(selector) {
      const found = [];
      this.each(el => {
        found.push(...el.querySelectorAll(selector));
      });
      return new DOMElement(found);
    }

    /**
     * 부모 요소 검색
     * @returns {DOMElement}
     */
    parent() {
      const parents = this.elements.map(el => el.parentElement).filter(Boolean);
      return new DOMElement(parents);
    }

    /**
     * 가장 가까운 조상 요소 검색
     * @param {string} selector - CSS 선택자
     * @returns {DOMElement}
     */
    closest(selector) {
      const found = this.elements.map(el => el.closest(selector)).filter(Boolean);
      return new DOMElement(found);
    }

    /**
     * 형제 요소 검색
     * @returns {DOMElement}
     */
    siblings() {
      const siblings = [];
      this.each(el => {
        const parent = el.parentElement;
        if (parent) {
          Array.from(parent.children).forEach(child => {
            if (child !== el && !siblings.includes(child)) {
              siblings.push(child);
            }
          });
        }
      });
      return new DOMElement(siblings);
    }

    /**
     * 다음 형제 요소
     * @returns {DOMElement}
     */
    next() {
      const next = this.elements.map(el => el.nextElementSibling).filter(Boolean);
      return new DOMElement(next);
    }

    /**
     * 이전 형제 요소
     * @returns {DOMElement}
     */
    prev() {
      const prev = this.elements.map(el => el.previousElementSibling).filter(Boolean);
      return new DOMElement(prev);
    }

    /**
     * 첫 번째 요소
     * @returns {DOMElement}
     */
    first() {
      return new DOMElement(this.elements[0] || []);
    }

    /**
     * 마지막 요소
     * @returns {DOMElement}
     */
    last() {
      return new DOMElement(this.elements[this.elements.length - 1] || []);
    }

    /**
     * 특정 인덱스 요소
     * @param {number} index - 인덱스
     * @returns {DOMElement}
     */
    eq(index) {
      return new DOMElement(this.elements[index] || []);
    }

    /**
     * 원본 DOM 요소 가져오기
     * @param {number} [index] - 인덱스 (없으면 전체 배열)
     * @returns {HTMLElement|HTMLElement[]}
     */
    get(index) {
      return index === undefined ? this.elements : this.elements[index];
    }
  }

  /**
   * DOM 유틸리티 클래스
   * @class
   * @description DOM 선택, 요소 생성 등의 유틸리티 메서드를 제공합니다.
   * IMCAT() 함수의 기본 구현체입니다.
   *
   * @example
   * // 요소 선택
   * const element = DOM.select('#app');
   *
   * @example
   * // 요소 생성
   * const div = DOM.create('div', { class: 'container' });
   */
  class DOM {
    /**
     * 요소 선택
     * @param {string|HTMLElement|DOMElement} selector - 선택자
     * @returns {DOMElement}
     */
    static select(selector) {
      if (!selector) return new DOMElement([]);
      if (typeof selector === 'string') {
        const elements = Array.from(document.querySelectorAll(selector));
        return new DOMElement(elements);
      }
      if (selector instanceof HTMLElement) {
        return new DOMElement([selector]);
      }
      if (selector instanceof DOMElement) {
        return selector;
      }
      return new DOMElement([]);
    }

    /**
     * 새 요소 생성
     * @param {string} tagName - HTML 태그 이름
     * @param {Object} [attributes] - 속성 객체
     * @returns {DOMElement}
     */
    static create(tagName) {
      let attributes = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      const el = document.createElement(tagName);
      Object.entries(attributes).forEach(_ref2 => {
        let [key, value] = _ref2;
        if (key === 'class') {
          el.className = value;
        } else if (key === 'html') {
          el.innerHTML = Security.sanitize(value);
        } else if (key === 'text') {
          el.textContent = value;
        } else {
          el.setAttribute(key, Security.escape(value));
        }
      });
      return new DOMElement([el]);
    }

    /**
     * DOM 준비 완료 시 실행
     * @param {Function} callback - 콜백 함수
     */
    static ready(callback) {
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', callback);
      } else {
        callback();
      }
    }
  }

  /**
   * 이벤트 시스템
   * @module core/event
   */

  /**
   * 이벤트 버스
   * @class
   * @description 전역 이벤트 버스를 통한 publish-subscribe 패턴을 제공합니다.
   * 컴포넌트 간 느슨한 결합으로 통신할 수 있습니다.
   *
   * @example
   * const bus = new EventBus();
   * bus.on('user:login', (data) => console.log(data));
   * bus.emit('user:login', { username: 'John' });
   */
  class EventBus {
    /**
     * EventBus 생성자
     * @constructor
     */
    constructor() {
      this.events = new Map();
    }

    /**
     * 이벤트 리스너 등록
     * @param {string} event - 이벤트 이름
     * @param {Function} handler - 이벤트 핸들러
     * @returns {Function} 구독 취소 함수
     *
     * @example
     * const unsubscribe = eventBus.on('user:login', (user) => {
     *   console.log('User logged in:', user);
     * });
     * // 구독 취소
     * unsubscribe();
     */
    on(event, handler) {
      if (!this.events.has(event)) {
        this.events.set(event, []);
      }
      this.events.get(event).push(handler);

      // 구독 취소 함수 반환
      return () => this.off(event, handler);
    }

    /**
     * 일회성 이벤트 리스너 등록
     * @param {string} event - 이벤트 이름
     * @param {Function} handler - 이벤트 핸들러
     * @returns {Function} 구독 취소 함수
     *
     * @example
     * eventBus.once('data:loaded', () => {
     *   console.log('Data loaded - this runs only once');
     * });
     */
    once(event, handler) {
      var _this = this;
      const wrapper = function () {
        handler(...arguments);
        _this.off(event, wrapper);
      };
      return this.on(event, wrapper);
    }

    /**
     * 이벤트 리스너 제거
     * @param {string} event - 이벤트 이름
     * @param {Function} [handler] - 이벤트 핸들러 (없으면 모든 핸들러 제거)
     *
     * @example
     * eventBus.off('user:login', handler); // 특정 핸들러 제거
     * eventBus.off('user:login'); // 모든 핸들러 제거
     */
    off(event, handler) {
      if (!this.events.has(event)) return;
      if (handler) {
        const handlers = this.events.get(event);
        const index = handlers.indexOf(handler);
        if (index !== -1) {
          handlers.splice(index, 1);
        }
        // 핸들러가 없으면 이벤트 자체를 제거
        if (handlers.length === 0) {
          this.events.delete(event);
        }
      } else {
        // 핸들러가 지정되지 않으면 모든 핸들러 제거
        this.events.delete(event);
      }
    }

    /**
     * 이벤트 발생
     * @param {string} event - 이벤트 이름
     * @param {...*} args - 핸들러에 전달할 인자들
     *
     * @example
     * eventBus.emit('user:login', { id: 1, name: 'John' });
     * eventBus.emit('data:updated', data, timestamp);
     */
    emit(event) {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      if (!this.events.has(event)) return;

      // 핸들러 배열 복사 (순회 중 변경 방지)
      const handlers = [...this.events.get(event)];
      handlers.forEach(handler => {
        try {
          handler(...args);
        } catch (error) {
          console.error(`Error in event handler for "${event}":`, error);
        }
      });
    }

    /**
     * 모든 리스너 제거
     *
     * @example
     * eventBus.clear(); // 모든 이벤트 리스너 제거
     */
    clear() {
      this.events.clear();
    }

    /**
     * 등록된 이벤트 목록 조회
     * @returns {string[]} 이벤트 이름 배열
     */
    getEvents() {
      return Array.from(this.events.keys());
    }

    /**
     * 특정 이벤트의 리스너 수 조회
     * @param {string} event - 이벤트 이름
     * @returns {number} 리스너 수
     */
    listenerCount(event) {
      return this.events.has(event) ? this.events.get(event).length : 0;
    }

    /**
     * 이벤트에 리스너가 있는지 확인
     * @param {string} event - 이벤트 이름
     * @returns {boolean}
     */
    hasListeners(event) {
      return this.events.has(event) && this.events.get(event).length > 0;
    }
  }

  /**
   * 모듈 로더
   * @module core/loader
   */

  /**
   * 모듈 로더 클래스
   * @class
   * @description JavaScript 모듈과 CSS를 동적으로 로드하는 클래스입니다.
   * 중복 로드를 방지하고 모듈을 캐싱합니다.
   *
   * @example
   * const loader = new ModuleLoader();
   * await loader.load('/modules/chart.js', '/modules/chart.css');
   */
  class ModuleLoader {
    /**
     * ModuleLoader 생성자
     * @constructor
     * @param {Object} options - 로더 옵션
     * @param {string} options.distPath - dist 폴더 경로 (기본: 자동 감지)
     */
    constructor() {
      let options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      this.modules = new Map();
      this.loadedCSS = new Set();

      // dist 폴더 경로 설정 (옵션 또는 자동 감지)
      this.distPath = options.distPath || this._detectDistPath();

      // 모듈 base path (distPath 기준)
      this.basePath = `${this.distPath}/modules`;
    }

    /**
     * dist 폴더 경로 자동 감지
     * @private
     * @returns {string} dist 폴더 경로
     */
    _detectDistPath() {
      // 현재 스크립트 위치에서 dist 찾기
      const scripts = document.getElementsByTagName('script');
      for (const script of scripts) {
        const src = script.src;
        if (src && src.includes('imcat-ui')) {
          // imcat-ui.js 또는 imcat-ui.min.js의 경로에서 dist 추출
          const match = src.match(/(.*)\/imcat-ui(\.min)?\.js/);
          if (match) {
            return match[1]; // dist 폴더 경로
          }
        }
      }

      // 기본값: 현재 위치 기준 상대 경로
      return './dist';
    }

    /**
     * 모듈 로드
     * @param {...string} moduleNames - 모듈 이름들
     * @returns {Promise<*>} 단일 또는 배열로 모듈 반환
     *
     * @example
     * // 단일 모듈
     * const Modal = await loader.use('modal');
     *
     * // 여러 모듈
     * const [Modal, Dropdown] = await loader.use('modal', 'dropdown');
     */
    async use() {
      for (var _len = arguments.length, moduleNames = new Array(_len), _key = 0; _key < _len; _key++) {
        moduleNames[_key] = arguments[_key];
      }
      // 단일 모듈
      if (moduleNames.length === 1) {
        return this._loadModule(moduleNames[0]);
      }

      // 여러 모듈
      const modules = await Promise.all(moduleNames.map(name => this._loadModule(name)));
      return modules;
    }

    /**
     * 모듈 사전 로드 (캐싱)
     * @param {...string} moduleNames - 모듈 이름들
     * @returns {Promise<void>}
     *
     * @example
     * await loader.preload('modal', 'dropdown', 'tooltip');
     */
    async preload() {
      for (var _len2 = arguments.length, moduleNames = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        moduleNames[_key2] = arguments[_key2];
      }
      await Promise.all(moduleNames.map(name => this._loadModule(name)));
    }

    /**
     * 모듈 로드 (내부)
     * @private
     * @param {string} moduleName - 모듈 이름
     * @returns {Promise<*>} 모듈
     */
    async _loadModule(moduleName) {
      // 캐시된 모듈 반환
      if (this.modules.has(moduleName)) {
        return this.modules.get(moduleName);
      }
      try {
        // CSS 로드
        await this._loadModuleCSS(moduleName);

        // JS 모듈 로드
        const modulePath = `${this.basePath}/${moduleName}/${moduleName}.js`;
        const module = await import(modulePath);

        // 기본 export 또는 named export
        const moduleExport = module.default || module[this._capitalize(moduleName)];
        if (!moduleExport) {
          throw new Error(`Module "${moduleName}" does not have a default or named export`);
        }

        // 캐시에 저장
        this.modules.set(moduleName, moduleExport);
        return moduleExport;
      } catch (error) {
        console.error(`Failed to load module "${moduleName}":`, error);
        throw new Error(`Module "${moduleName}" not found`);
      }
    }

    /**
     * 모듈 CSS 로드
     * @private
     * @param {string} moduleName - 모듈 이름
     */
    async _loadModuleCSS(moduleName) {
      const cssPath = `${this.basePath}/${moduleName}/${moduleName}.css`;

      // 이미 로드된 CSS는 스킵
      if (this.loadedCSS.has(cssPath)) {
        return;
      }
      try {
        await this.loadCSS(cssPath);
        this.loadedCSS.add(cssPath);
      } catch (error) {
        // CSS가 없으면 무시 (선택적)
        console.warn(`CSS not found for module "${moduleName}"`);
      }
    }

    /**
     * CSS 파일 로드
     * @param {string} url - CSS 파일 URL
     * @returns {Promise<void>}
     *
     * @example
     * await loader.loadCSS('./styles/custom.css');
     */
    loadCSS(url) {
      return new Promise((resolve, reject) => {
        // 이미 로드된 CSS 확인
        if (this.loadedCSS.has(url)) {
          resolve();
          return;
        }
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = url;
        link.onload = () => {
          this.loadedCSS.add(url);
          resolve();
        };
        link.onerror = () => {
          reject(new Error(`Failed to load CSS: ${url}`));
        };
        document.head.appendChild(link);
      });
    }

    /**
     * 로드된 모듈 가져오기
     * @param {string} moduleName - 모듈 이름
     * @returns {*|null} 모듈 또는 null
     *
     * @example
     * const Modal = loader.getModule('modal');
     */
    getModule(moduleName) {
      return this.modules.get(moduleName) || null;
    }

    /**
     * 모듈 로드 여부 확인
     * @param {string} moduleName - 모듈 이름
     * @returns {boolean}
     *
     * @example
     * if (loader.hasModule('modal')) {
     *   console.log('Modal already loaded');
     * }
     */
    hasModule(moduleName) {
      return this.modules.has(moduleName);
    }

    /**
     * 기본 경로 설정
     * @param {string} path - 모듈 기본 경로
     *
     * @example
     * loader.setBasePath('./custom/modules');
     */
    setBasePath(path) {
      this.basePath = path;
    }

    /**
     * 모듈 캐시 초기화
     * @param {string} [moduleName] - 특정 모듈만 초기화 (선택)
     *
     * @example
     * loader.clearCache(); // 전체 초기화
     * loader.clearCache('modal'); // 특정 모듈만
     */
    clearCache(moduleName) {
      if (moduleName) {
        this.modules.delete(moduleName);
      } else {
        this.modules.clear();
      }
    }

    /**
     * 로드된 모듈 목록
     * @returns {string[]} 모듈 이름 배열
     */
    getLoadedModules() {
      return Array.from(this.modules.keys());
    }

    /**
     * 로드된 CSS 목록
     * @returns {string[]} CSS URL 배열
     */
    getLoadedCSS() {
      return Array.from(this.loadedCSS);
    }

    /**
     * 첫 글자 대문자 변환
     * @private
     * @param {string} str - 문자열
     * @returns {string}
     */
    _capitalize(str) {
      return str.charAt(0).toUpperCase() + str.slice(1);
    }

    /**
     * 모듈 로더 정리 (메모리 누수 방지)
     * 모듈 캐시를 정리합니다. CSS는 DOM에 유지됩니다.
     *
     * @example
     * // 애플리케이션 종료 시
     * loader.destroy();
     */
    destroy() {
      // 모듈 캐시 정리
      this.modules.clear();

      // CSS는 DOM에 남겨둠 (제거 시 스타일 깨짐)
      // 필요시 별도로 CSS 정리 가능
      // this.loadedCSS.clear();
    }
  }

  /**
   * SPA 뷰 라우터
   * @module core/router
   */


  /**
   * 뷰 라우터
   * @class
   * @description SPA(Single Page Application) 라우팅을 처리하는 클래스입니다.
   * History API를 사용하여 페이지 전환을 관리하고, views/ 폴더 하위 경로를 지원합니다.
   *
   * @example
   * const router = new ViewRouter();
   * router.navigate('views/home.html');
   */
  class ViewRouter {
    /**
     * ViewRouter 생성자
     * @constructor
     */
    constructor() {
      this.container = '#app';
      this.currentPath = '';
      this.hooks = {
        beforeLoad: [],
        afterLoad: [],
        onError: []
      };
      // 인스턴스 관리
      this.instances = new Map();
      this.currentViewInstances = [];
      this.loading = null;
      this._popstateHandler = null;

      // History API 사용 여부 (기본값: true)
      this.useHistory = true;
    }

    /**
     * 초기화
     * @param {Object} [options] - 옵션
     * @param {Object} [options.loading] - 로딩 인디케이터 인스턴스
     * @param {boolean} [options.autoNavigate=true] - 초기 hash 경로 자동 로드 여부
     * @param {boolean} [options.useHistory=true] - History API 사용 여부 (false면 URL 변경 안함)
     */
    init() {
      let options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      if (options.loading) {
        this.loading = options.loading;
      }

      // History API 사용 여부 설정
      if ('useHistory' in options) {
        this.useHistory = options.useHistory;
      }

      // History API 이벤트 리스너 (useHistory가 true일 때만)
      if (this.useHistory) {
        this._popstateHandler = e => {
          var _e$state;
          if ((_e$state = e.state) !== null && _e$state !== void 0 && _e$state.path) {
            this._loadView(e.state.path, false);
          }
        };
        window.addEventListener('popstate', this._popstateHandler);
      }

      // 초기 경로 자동 로드 (useHistory가 true일 때만)
      const autoNavigate = 'autoNavigate' in options ? options.autoNavigate : true;
      if (autoNavigate && this.useHistory) {
        const initialPath = window.location.hash.slice(1) || '';
        if (initialPath) {
          this.navigate(initialPath, true);
        }
      }
    }

    /**
     * 페이지 이동
     * @param {string} path - 페이지 경로
     * @param {boolean} [replace=false] - 히스토리 교체 여부
     * @returns {Promise<void>}
     *
     * @example
     * router.navigate('views/home.html');
     * router.navigate('views/login.html', true); // 히스토리 교체
     */
    async navigate(path) {
      let replace = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      // 경로 보안 검증
      if (!Security.validatePath(path)) {
        console.error('Invalid path:', path);
        await this._emitHook('onError', new Error('Invalid path'));
        return;
      }
      await this._loadView(path, !replace);
    }

    /**
     * 뷰 로드
     * @private
     * @param {string} path - 경로 (쿼리 스트링 포함 가능)
     * @param {boolean} [pushState=true] - pushState 사용 여부
     */
    async _loadView(path) {
      let pushState = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      const from = this.currentPath;
      try {
        // 이전 뷰의 인스턴스 정리
        this._cleanupCurrentView();

        // beforeLoad 훅
        await this._emitHook('beforeLoad', path, from);

        // 로딩 표시
        if (this.loading) {
          this.loading.show('페이지 로딩 중...');
        }

        // 쿼리 스트링 분리 (fetch는 파일 경로만 필요)
        const [filePath] = path.split('?');

        // HTML 파일 가져오기
        const response = await fetch(filePath);
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const html = await response.text();

        // 뷰 파일 렌더링
        // views/ 폴더 및 하위 폴더의 뷰 파일은 개발자가 작성한 신뢰할 수 있는 파일이므로
        // sanitize를 건너뛰고 스크립트와 스타일을 그대로 허용합니다.
        //
        // 보안 정책:
        // - Security.validatePath()로 views/ 외부 경로 차단
        // - 경로 순회 공격(..), 절대 경로 차단
        // - 사용자 입력은 뷰 내부에서 IMCAT.escape()로 처리
        // - views/admin/dashboard.html 같은 하위 폴더도 지원

        // 컨테이너에 렌더링
        const container = document.querySelector(this.container);
        if (container) {
          container.innerHTML = html;

          // 스크립트 실행
          this._executeScripts(container);
        }

        // History API 업데이트 (useHistory가 true일 때만)
        if (pushState && this.useHistory) {
          window.history.pushState({
            path
          }, '', `#${path}`);
        }
        this.currentPath = path;

        // afterLoad 훅
        await this._emitHook('afterLoad', path);
      } catch (error) {
        console.error('Failed to load view:', error);
        await this._emitHook('onError', error);
      } finally {
        // 로딩 숨김
        if (this.loading) {
          this.loading.hide();
        }
      }
    }

    /**
     * 스크립트 실행
     * @private
     * @param {HTMLElement} container - 컨테이너
     */
    _executeScripts(container) {
      const scripts = container.querySelectorAll('script');
      scripts.forEach(oldScript => {
        const newScript = document.createElement('script');

        // 속성 복사
        Array.from(oldScript.attributes).forEach(attr => {
          newScript.setAttribute(attr.name, attr.value);
        });

        // 내용 복사
        newScript.textContent = oldScript.textContent;

        // 기존 스크립트 교체
        oldScript.parentNode.replaceChild(newScript, oldScript);
      });
    }

    /**
     * URL 파라미터 조회
     * @returns {Object} 파라미터 객체
     *
     * @example
     * // URL: #views/product.html?id=123&color=red
     * const params = router.params();
     * console.log(params.id); // '123'
     * console.log(params.color); // 'red'
     */
    params() {
      const hash = window.location.hash.slice(1);
      const [, queryString] = hash.split('?');
      if (!queryString) return {};
      const params = {};
      const searchParams = new URLSearchParams(queryString);
      for (const [key, value] of searchParams) {
        // 이스케이프 없이 원본 값 반환 (뷰에서 사용 시)
        params[key] = value;
      }
      return params;
    }

    /**
     * 뒤로 가기
     *
     * @example
     * router.back();
     */
    back() {
      window.history.back();
    }

    /**
     * 앞으로 가기
     *
     * @example
     * router.forward();
     */
    forward() {
      window.history.forward();
    }

    /**
     * 현재 경로
     * @returns {string} 현재 경로
     *
     * @example
     * const path = router.current(); // 'views/home.html'
     */
    current() {
      return this.currentPath;
    }

    /**
     * 컨테이너 설정
     * @param {string} selector - CSS 선택자
     *
     * @example
     * router.setContainer('#main-content');
     */
    setContainer(selector) {
      this.container = selector;
    }

    /**
     * 인스턴스 등록 (메모리 누수 방지)
     * @param {Object} instance - destroy() 메서드를 가진 인스턴스
     * @returns {Object} 등록된 인스턴스
     *
     * @example
     * const modal = new Modal();
     * router.registerInstance(modal);
     * // 뷰 전환 시 modal.destroy() 자동 호출됨
     */
    registerInstance(instance) {
      if (instance && typeof instance.destroy === 'function') {
        this.currentViewInstances.push(instance);
        return instance;
      }
      console.warn('Instance must have destroy() method');
      return instance;
    }

    /**
     * 현재 뷰의 모든 인스턴스 정리
     * @private
     */
    _cleanupCurrentView() {
      // 현재 뷰의 모든 인스턴스 정리
      this.currentViewInstances.forEach(instance => {
        try {
          if (instance && typeof instance.destroy === 'function') {
            instance.destroy();
          }
        } catch (error) {
          console.error('Error destroying instance:', error);
        }
      });

      // 인스턴스 배열 초기화
      this.currentViewInstances = [];
    }

    /**
     * beforeLoad 훅 등록
     * @param {Function} handler - 핸들러 (path, from) => {}
     * @returns {Function} 구독 취소 함수
     *
     * @example
     * const unsubscribe = router.beforeLoad((path, from) => {
     *   console.log(`${from} → ${path}`);
     * });
     */
    beforeLoad(handler) {
      this.hooks.beforeLoad.push(handler);
      return () => this._removeHook('beforeLoad', handler);
    }

    /**
     * afterLoad 훅 등록
     * @param {Function} handler - 핸들러 (path) => {}
     * @returns {Function} 구독 취소 함수
     *
     * @example
     * router.afterLoad((path) => {
     *   console.log('로드 완료:', path);
     * });
     */
    afterLoad(handler) {
      this.hooks.afterLoad.push(handler);
      return () => this._removeHook('afterLoad', handler);
    }

    /**
     * onError 훅 등록
     * @param {Function} handler - 핸들러 (error) => {}
     * @returns {Function} 구독 취소 함수
     *
     * @example
     * router.onError((error) => {
     *   console.error('로드 실패:', error);
     * });
     */
    onError(handler) {
      this.hooks.onError.push(handler);
      return () => this._removeHook('onError', handler);
    }

    /**
     * 훅 실행
     * @private
     * @param {string} name - 훅 이름
     * @param {...*} args - 인자
     */
    async _emitHook(name) {
      const handlers = this.hooks[name] || [];
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      for (const handler of handlers) {
        try {
          await handler(...args);
        } catch (error) {
          console.error(`Error in ${name} hook:`, error);
        }
      }
    }

    /**
     * 훅 제거
     * @private
     * @param {string} name - 훅 이름
     * @param {Function} handler - 핸들러
     */
    _removeHook(name, handler) {
      const handlers = this.hooks[name];
      const index = handlers.indexOf(handler);
      if (index !== -1) {
        handlers.splice(index, 1);
      }
    }

    /**
     * 모든 훅 제거
     */
    clearHooks() {
      this.hooks.beforeLoad = [];
      this.hooks.afterLoad = [];
      this.hooks.onError = [];
    }

    /**
     * 등록된 인스턴스 수
     * @returns {number}
     */
    getInstanceCount() {
      return this.currentViewInstances.length;
    }

    /**
     * 라우터 정리 (메모리 누수 방지)
     * 이벤트 리스너와 인스턴스 모두 정리
     */
    destroy() {
      // popstate 이벤트 리스너 제거
      if (this._popstateHandler) {
        window.removeEventListener('popstate', this._popstateHandler);
        this._popstateHandler = null;
      }

      // 현재 뷰의 인스턴스 정리
      this._cleanupCurrentView();

      // 모든 훅 제거
      this.clearHooks();

      // 로딩 인디케이터 정리
      if (this.loading && typeof this.loading.forceHide === 'function') {
        this.loading.forceHide();
      }

      // 상태 초기화
      this.currentPath = '';
      this.instances.clear();
    }
  }

  /**
   * 로딩 인디케이터
   * @module core/loading
   */

  /**
   * 로딩 인디케이터 클래스
   * @class
   * @description 로딩 스피너를 표시하고 숨기는 기능을 제공합니다.
   * 다양한 스타일(spinner, progress)을 지원합니다.
   *
   * @example
   * const loading = new LoadingIndicator();
   * loading.show('로딩 중...');
   */
  class LoadingIndicator {
    /**
     * LoadingIndicator 생성자
     * @constructor
     */
    constructor() {
      this.element = null;
      this.config = {
        style: 'spinner',
        // 'spinner', 'bar', 'dots'
        color: '#007bff',
        position: 'center',
        // 'center', 'top'
        delay: 200 // ms
      };
      this.showTimer = null;
      this.hideTimer = null;
      this.isShowing = false;
    }

    /**
     * 로딩 표시
     * @param {string} [message=''] - 로딩 메시지
     *
     * @example
     * loading.show('데이터 로딩 중...');
     */
    show() {
      let message = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
      // 이미 표시 중이면 무시
      if (this.isShowing) return;

      // 기존 타이머 취소
      if (this.hideTimer) {
        clearTimeout(this.hideTimer);
        this.hideTimer = null;
      }

      // delay 후에 표시 (빠른 로딩은 표시 안함)
      this.showTimer = setTimeout(() => {
        this._createElement(message);
        this._show();
        this.isShowing = true;
      }, this.config.delay);
    }

    /**
     * 로딩 숨김
     *
     * @example
     * loading.hide();
     */
    hide() {
      // 타이머 취소
      if (this.showTimer) {
        clearTimeout(this.showTimer);
        this.showTimer = null;
      }
      if (!this.isShowing) return;

      // 부드러운 페이드아웃
      this.hideTimer = setTimeout(() => {
        this._hide();
        this.isShowing = false;
      }, 100);
    }

    /**
     * 진행률 설정 (프로그레스 바)
     * @param {number} percent - 진행률 (0-100)
     *
     * @example
     * loading.progress(50); // 50%
     */
    progress(percent) {
      if (!this.element) return;
      const bar = this.element.querySelector('.imcat-loading-bar-fill');
      if (bar) {
        bar.style.width = `${Math.max(0, Math.min(100, percent))}%`;
      }
    }

    /**
     * 설정 변경
     * @param {Object} options - 설정 옵션
     * @param {string} [options.style] - 스타일 ('spinner', 'bar', 'dots')
     * @param {string} [options.color] - 색상
     * @param {string} [options.position] - 위치 ('center', 'top')
     * @param {number} [options.delay] - 지연 시간 (ms)
     *
     * @example
     * loading.setConfig({
     *   style: 'bar',
     *   color: '#ff0000',
     *   position: 'top',
     *   delay: 300
     * });
     */
    setConfig(options) {
      Object.assign(this.config, options);
    }

    /**
     * 엘리먼트 생성
     * @private
     * @param {string} message - 메시지
     */
    _createElement(message) {
      if (this.element) return;
      this.element = document.createElement('div');
      this.element.className = `imcat-loading imcat-loading-${this.config.position}`;
      let innerHTML = '';
      if (this.config.style === 'spinner') {
        innerHTML = `
        <div class="imcat-loading-spinner">
          <div class="imcat-spinner"></div>
          ${message ? `<div class="imcat-loading-message">${message}</div>` : ''}
        </div>
      `;
      } else if (this.config.style === 'bar') {
        innerHTML = `
        <div class="imcat-loading-bar">
          <div class="imcat-loading-bar-fill"></div>
        </div>
      `;
      } else if (this.config.style === 'dots') {
        innerHTML = `
        <div class="imcat-loading-dots">
          <span></span><span></span><span></span>
          ${message ? `<div class="imcat-loading-message">${message}</div>` : ''}
        </div>
      `;
      }
      this.element.innerHTML = innerHTML;

      // CSS 변수 적용
      this.element.style.setProperty('--imcat-loading-color', this.config.color);

      // 기본 스타일 추가
      this._addDefaultStyles();
    }

    /**
     * 기본 스타일 추가
     * @private
     */
    _addDefaultStyles() {
      if (document.getElementById('imcat-loading-styles')) return;
      const style = document.createElement('style');
      style.id = 'imcat-loading-styles';
      style.textContent = `
      .imcat-loading {
        position: fixed;
        z-index: 9999;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transition: opacity 0.3s ease;
      }
      
      .imcat-loading-center {
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
      }
      
      .imcat-loading-top {
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: transparent;
      }
      
      .imcat-loading-show {
        opacity: 1;
      }
      
      .imcat-loading-spinner {
        text-align: center;
      }
      
      .imcat-spinner {
        width: 50px;
        height: 50px;
        border: 4px solid rgba(255, 255, 255, 0.3);
        border-top-color: var(--imcat-loading-color, #007bff);
        border-radius: 50%;
        animation: imcat-spin 1s linear infinite;
      }
      
      @keyframes imcat-spin {
        to { transform: rotate(360deg); }
      }
      
      .imcat-loading-bar {
        width: 100%;
        height: 4px;
        background: rgba(255, 255, 255, 0.2);
      }
      
      .imcat-loading-bar-fill {
        height: 100%;
        background: var(--imcat-loading-color, #007bff);
        transition: width 0.3s ease;
        width: 0%;
      }
      
      .imcat-loading-dots {
        display: flex;
        gap: 10px;
        align-items: center;
        flex-direction: column;
      }
      
      .imcat-loading-dots > span {
        width: 12px;
        height: 12px;
        background: var(--imcat-loading-color, #007bff);
        border-radius: 50%;
        display: inline-block;
        animation: imcat-bounce 1.4s infinite ease-in-out both;
      }
      
      .imcat-loading-dots > span:nth-child(1) {
        animation-delay: -0.32s;
      }
      
      .imcat-loading-dots > span:nth-child(2) {
        animation-delay: -0.16s;
      }
      
      @keyframes imcat-bounce {
        0%, 80%, 100% {
          transform: scale(0);
        }
        40% {
          transform: scale(1);
        }
      }
      
      .imcat-loading-message {
        margin-top: 15px;
        color: white;
        font-size: 14px;
      }
    `;
      document.head.appendChild(style);
    }

    /**
     * 표시
     * @private
     */
    _show() {
      if (!this.element) return;
      document.body.appendChild(this.element);

      // 애니메이션을 위한 reflow
      this.element.offsetHeight;
      this.element.classList.add('imcat-loading-show');
    }

    /**
     * 숨김
     * @private
     */
    _hide() {
      if (!this.element) return;
      this.element.classList.remove('imcat-loading-show');
      setTimeout(() => {
        var _this$element;
        (_this$element = this.element) === null || _this$element === void 0 || _this$element.remove();
        this.element = null;
      }, 300);
    }

    /**
     * 현재 표시 상태
     * @returns {boolean}
     */
    isVisible() {
      return this.isShowing;
    }

    /**
     * 강제로 즉시 숨김 (타이머 무시)
     */
    forceHide() {
      if (this.showTimer) {
        clearTimeout(this.showTimer);
        this.showTimer = null;
      }
      if (this.hideTimer) {
        clearTimeout(this.hideTimer);
        this.hideTimer = null;
      }
      if (this.element) {
        this.element.remove();
        this.element = null;
      }
      this.isShowing = false;
    }

    /**
     * 로딩 인디케이터 정리 (메모리 누수 방지)
     * 모든 타이머와 DOM 요소를 정리합니다.
     *
     * @example
     * // 애플리케이션 종료 시
     * LoadingIndicator.destroy();
     */
    destroy() {
      // 모든 타이머 정리
      if (this.showTimer) {
        clearTimeout(this.showTimer);
        this.showTimer = null;
      }
      if (this.hideTimer) {
        clearTimeout(this.hideTimer);
        this.hideTimer = null;
      }

      // DOM 요소 제거
      if (this.element) {
        this.element.remove();
        this.element = null;
      }

      // 상태 초기화
      this.isShowing = false;
    }
  }

  // 싱글톤 인스턴스
  var LoadingIndicator$1 = new LoadingIndicator();

  function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
      value: t,
      enumerable: true,
      configurable: true,
      writable: true
    }) : e[r] = t, e;
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r);
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
  }

  var _APIUtil;
  /**
   * API 유틸리티
   * @module core/api
   */

  /**
   * API 유틸리티 클래스
   * @class
   * @description HTTP 요청을 위한 fetch API 래퍼 클래스입니다.
   * 표준화된 응답 형식, 인터셉터, 에러 처리 등을 제공합니다.
   *
   * @example
   * // GET 요청
   * const response = await APIUtil.get('/api/users');
   *
   * @example
   * // POST 요청
   * const response = await APIUtil.post('/api/users', { name: 'John' });
   */
  class APIUtil {
    /**
     * 성공 응답 생성
     * @param {*} data - 응답 데이터
     * @param {string} [message='Success'] - 메시지
     * @param {number} [statusCode=200] - HTTP 상태 코드
     * @returns {Object} 표준 응답 객체
     *
     * @example
     * const response = APIUtil.success({ id: 1, name: 'John' }, 'User created', 201);
     */
    static success(data) {
      let message = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'Success';
      let statusCode = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 200;
      return {
        success: true,
        statusCode,
        data,
        message,
        error: null,
        timestamp: Date.now()
      };
    }

    /**
     * 에러 응답 생성
     * @param {string} message - 에러 메시지
     * @param {number} [statusCode=400] - HTTP 상태 코드
     * @param {Object} [error=null] - 에러 상세
     * @returns {Object} 표준 에러 객체
     *
     * @example
     * const response = APIUtil.error('User not found', 404);
     */
    static error(message) {
      let statusCode = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 400;
      let error = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
      return {
        success: false,
        statusCode,
        data: null,
        message,
        error: error ? {
          message: error.message || message,
          name: error.name,
          type: error.type
        } : {
          message
        },
        timestamp: Date.now()
      };
    }

    /**
     * 페이지네이션 응답 생성
     * @param {Array} items - 아이템 배열
     * @param {Object} pagination - 페이지 정보
     * @param {number} pagination.page - 현재 페이지
     * @param {number} pagination.limit - 페이지당 아이템 수
     * @param {number} pagination.total - 전체 아이템 수
     * @returns {Object} 페이지네이션 응답
     *
     * @example
     * const response = APIUtil.paginated(items, {
     *   page: 1,
     *   limit: 10,
     *   total: 100
     * });
     */
    static paginated(items, pagination) {
      const {
        page,
        limit,
        total
      } = pagination;
      const totalPages = Math.ceil(total / limit);
      return this.success({
        items,
        pagination: {
          page,
          limit,
          total,
          totalPages,
          hasNext: page < totalPages,
          hasPrev: page > 1
        }
      });
    }

    /**
     * HTTP 요청 (기본)
     * @param {string} url - 요청 URL
     * @param {Object} [options={}] - fetch 옵션
     * @returns {Promise<Object>} API 응답
     *
     * @example
     * const response = await APIUtil.request('/api/users', {
     *   method: 'POST',
     *   body: JSON.stringify({ name: 'John' })
     * });
     */
    static async request(url) {
      let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      try {
        // 기본 헤더 설정
        const headers = {
          'Content-Type': 'application/json',
          ...options.headers
        };
        let config = {
          ...options,
          headers,
          url // URL도 config에 포함
        };

        // 요청 인터셉터 실행
        for (const interceptor of this._requestInterceptors) {
          if (interceptor && interceptor.onFulfilled) {
            try {
              config = await interceptor.onFulfilled(config);
            } catch (error) {
              if (interceptor.onRejected) {
                config = await interceptor.onRejected(error);
              } else {
                throw error;
              }
            }
          }
        }

        // URL 추출 (인터셉터에서 변경되었을 수 있음)
        const finalUrl = config.url || url;
        delete config.url; // fetch에 전달하지 않음

        const response = await fetch(finalUrl, config);

        // JSON 파싱 (실패 시 텍스트로 처리)
        let data;
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
          try {
            data = await response.json();
          } catch (parseError) {
            data = {
              message: 'Invalid JSON response'
            };
          }
        } else {
          const text = await response.text();
          data = {
            message: text || 'Non-JSON response'
          };
        }
        let result;
        if (!response.ok) {
          result = this.error(data.message || 'Request failed', response.status, data.error);
        } else {
          // 서버가 표준 형식을 반환하면 그대로 사용
          if (data.success !== undefined) {
            result = data;
          } else {
            // 아니면 표준 형식으로 래핑
            result = this.success(data);
          }
        }

        // 응답 인터셉터 실행
        for (const interceptor of this._responseInterceptors) {
          if (interceptor) {
            if (result.success && interceptor.onFulfilled) {
              result = await interceptor.onFulfilled(result);
            } else if (!result.success && interceptor.onRejected) {
              result = await interceptor.onRejected(result);
            }
          }
        }
        return result;
      } catch (error) {
        // 네트워크 오류
        let result = this.error(error.message || 'Network error', 0,
        // 0 = 네트워크 오류
        error);

        // 에러에 대한 응답 인터셉터 실행
        for (const interceptor of this._responseInterceptors) {
          if (interceptor && interceptor.onRejected) {
            try {
              result = await interceptor.onRejected(result);
            } catch (e) {
              // 인터셉터에서 에러가 발생하면 원래 에러 반환
              break;
            }
          }
        }
        return result;
      }
    }

    /**
     * GET 요청
     * @param {string} url - 요청 URL
     * @param {Object} [options={}] - fetch 옵션
     * @returns {Promise<Object>} API 응답
     *
     * @example
     * const response = await APIUtil.get('/api/users');
     * if (response.success) {
     *   console.log(response.data);
     * }
     */
    static async get(url) {
      let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      return this.request(url, {
        ...options,
        method: 'GET'
      });
    }

    /**
     * POST 요청
     * @param {string} url - 요청 URL
     * @param {Object} body - 요청 바디
     * @param {Object} [options={}] - fetch 옵션
     * @returns {Promise<Object>} API 응답
     *
     * @example
     * const response = await APIUtil.post('/api/users', {
     *   name: 'John',
     *   email: 'john@example.com'
     * });
     */
    static async post(url, body) {
      let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return this.request(url, {
        ...options,
        method: 'POST',
        body: JSON.stringify(body)
      });
    }

    /**
     * PUT 요청
     * @param {string} url - 요청 URL
     * @param {Object} body - 요청 바디
     * @param {Object} [options={}] - fetch 옵션
     * @returns {Promise<Object>} API 응답
     *
     * @example
     * const response = await APIUtil.put('/api/users/123', {
     *   name: 'Jane'
     * });
     */
    static async put(url, body) {
      let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return this.request(url, {
        ...options,
        method: 'PUT',
        body: JSON.stringify(body)
      });
    }

    /**
     * PATCH 요청
     * @param {string} url - 요청 URL
     * @param {Object} body - 요청 바디
     * @param {Object} [options={}] - fetch 옵션
     * @returns {Promise<Object>} API 응답
     *
     * @example
     * const response = await APIUtil.patch('/api/users/123', {
     *   age: 31
     * });
     */
    static async patch(url, body) {
      let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return this.request(url, {
        ...options,
        method: 'PATCH',
        body: JSON.stringify(body)
      });
    }

    /**
     * DELETE 요청
     * @param {string} url - 요청 URL
     * @param {Object} [options={}] - fetch 옵션
     * @returns {Promise<Object>} API 응답
     *
     * @example
     * const response = await APIUtil.delete('/api/users/123');
     */
    static async delete(url) {
      let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      return this.request(url, {
        ...options,
        method: 'DELETE'
      });
    }

    /**
     * 여러 요청을 병렬로 실행
     * @param {...Promise} requests - 요청 프로미스들
     * @returns {Promise<Array>} 모든 응답 배열
     *
     * @example
     * const [users, posts, comments] = await APIUtil.all(
     *   APIUtil.get('/api/users'),
     *   APIUtil.get('/api/posts'),
     *   APIUtil.get('/api/comments')
     * );
     */
    static async all() {
      for (var _len = arguments.length, requests = new Array(_len), _key = 0; _key < _len; _key++) {
        requests[_key] = arguments[_key];
      }
      return Promise.all(requests);
    }

    /**
     * 여러 요청 중 가장 빠른 것만 반환
     * @param {...Promise} requests - 요청 프로미스들
     * @returns {Promise<Object>} 가장 빠른 응답
     *
     * @example
     * const response = await APIUtil.race(
     *   APIUtil.get('/api/server1/data'),
     *   APIUtil.get('/api/server2/data')
     * );
     */
    static async race() {
      for (var _len2 = arguments.length, requests = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        requests[_key2] = arguments[_key2];
      }
      return Promise.race(requests);
    }
  }
  _APIUtil = APIUtil;
  // 인터셉터 저장소
  _defineProperty(APIUtil, "_requestInterceptors", []);
  _defineProperty(APIUtil, "_responseInterceptors", []);
  /**
   * 인터셉터 객체
   */
  _defineProperty(APIUtil, "interceptors", {
    /**
     * 요청 인터셉터
     */
    request: {
      /**
       * 요청 인터셉터 추가
       * @param {Function} onFulfilled - 성공 핸들러
       * @param {Function} [onRejected] - 실패 핸들러
       * @returns {number} 인터셉터 ID
       *
       * @example
       * const id = APIUtil.interceptors.request.use(
       *   (config) => {
       *     config.headers['Authorization'] = `Bearer ${token}`;
       *     return config;
       *   }
       * );
       */
      use(onFulfilled, onRejected) {
        _APIUtil._requestInterceptors.push({
          onFulfilled,
          onRejected
        });
        return _APIUtil._requestInterceptors.length - 1;
      },
      /**
       * 요청 인터셉터 제거
       * @param {number} id - 인터셉터 ID
       */
      eject(id) {
        if (_APIUtil._requestInterceptors[id]) {
          _APIUtil._requestInterceptors[id] = null;
        }
      },
      /**
       * 모든 요청 인터셉터 제거
       */
      clear() {
        _APIUtil._requestInterceptors = [];
      }
    },
    /**
     * 응답 인터셉터
     */
    response: {
      /**
       * 응답 인터셉터 추가
       * @param {Function} onFulfilled - 성공 핸들러
       * @param {Function} [onRejected] - 실패 핸들러
       * @returns {number} 인터셉터 ID
       *
       * @example
       * APIUtil.interceptors.response.use(
       *   (response) => response,
       *   (error) => {
       *     if (error.statusCode === 401) {
       *       // 로그아웃 처리
       *     }
       *     return Promise.reject(error);
       *   }
       * );
       */
      use(onFulfilled, onRejected) {
        _APIUtil._responseInterceptors.push({
          onFulfilled,
          onRejected
        });
        return _APIUtil._responseInterceptors.length - 1;
      },
      /**
       * 응답 인터셉터 제거
       * @param {number} id - 인터셉터 ID
       */
      eject(id) {
        if (_APIUtil._responseInterceptors[id]) {
          _APIUtil._responseInterceptors[id] = null;
        }
      },
      /**
       * 모든 응답 인터셉터 제거
       */
      clear() {
        _APIUtil._responseInterceptors = [];
      }
    },
    /**
     * 모든 인터셉터 제거
     */
    clear() {
      _APIUtil._requestInterceptors = [];
      _APIUtil._responseInterceptors = [];
    }
  });

  /**
   * 기본 유틸리티
   * @module core/utils
   */

  /**
   * @class
   * @description 다양한 유틸리티 함수를 제공하는 클래스입니다.
   * 타입 체크, 객체 조작, 디바운스/스로틀 등의 기능을 포함합니다.
   *
   * @example
   * Utils.isString('hello'); // true
   * Utils.debounce(fn, 300);
   */
  class Utils {
    /**
     * 타입 체크 - 문자열
     * @param {*} value - 검사할 값
     * @returns {boolean}
     */
    static isString(value) {
      return typeof value === 'string';
    }

    /**
     * 타입 체크 - 숫자
     * @param {*} value - 검사할 값
     * @returns {boolean}
     */
    static isNumber(value) {
      return typeof value === 'number' && !isNaN(value);
    }

    /**
     * 타입 체크 - 불리언
     * @param {*} value - 검사할 값
     * @returns {boolean}
     */
    static isBoolean(value) {
      return typeof value === 'boolean';
    }

    /**
     * 타입 체크 - 객체
     * @param {*} value - 검사할 값
     * @returns {boolean}
     */
    static isObject(value) {
      return value !== null && typeof value === 'object' && !Array.isArray(value);
    }

    /**
     * 타입 체크 - 배열
     * @param {*} value - 검사할 값
     * @returns {boolean}
     */
    static isArray(value) {
      return Array.isArray(value);
    }

    /**
     * 타입 체크 - 함수
     * @param {*} value - 검사할 값
     * @returns {boolean}
     */
    static isFunction(value) {
      return typeof value === 'function';
    }

    /**
     * 타입 체크 - null
     * @param {*} value - 검사할 값
     * @returns {boolean}
     */
    static isNull(value) {
      return value === null;
    }

    /**
     * 타입 체크 - undefined
     * @param {*} value - 검사할 값
     * @returns {boolean}
     */
    static isUndefined(value) {
      return value === undefined;
    }

    /**
     * 타입 체크 - null 또는 undefined
     * @param {*} value - 검사할 값
     * @returns {boolean}
     */
    static isNullOrUndefined(value) {
      return value === null || value === undefined;
    }

    /**
     * 객체 병합 (깊은 병합)
     * @param {Object} target - 대상 객체
     * @param {...Object} sources - 소스 객체들
     * @returns {Object} 병합된 객체
     *
     * @example
     * Utils.extend({}, { a: 1 }, { b: 2 }); // { a: 1, b: 2 }
     */
    static extend(target) {
      for (var _len = arguments.length, sources = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        sources[_key - 1] = arguments[_key];
      }
      sources.forEach(source => {
        if (this.isObject(source)) {
          Object.keys(source).forEach(key => {
            if (this.isObject(source[key]) && this.isObject(target[key])) {
              target[key] = this.extend({}, target[key], source[key]);
            } else {
              target[key] = source[key];
            }
          });
        }
      });
      return target;
    }

    /**
     * 깊은 복사
     * @param {*} obj - 복사할 객체
     * @returns {*} 복사된 객체
     *
     * @example
     * const copy = Utils.clone({ a: { b: 1 } });
     *
     * @note
     * - 일반 객체 및 배열만 지원
     * - Date, RegExp, Map, Set, Function 등 특수 객체는 참조로 복사됨
     * - 순환 참조는 처리하지 않음 (스택 오버플로우 발생 가능)
     * - 복잡한 객체는 lodash.cloneDeep 사용 권장
     */
    static clone(obj) {
      if (this.isNullOrUndefined(obj)) return obj;
      if (this.isArray(obj)) return obj.map(item => this.clone(item));
      if (this.isObject(obj)) {
        const cloned = {};
        Object.keys(obj).forEach(key => {
          cloned[key] = this.clone(obj[key]);
        });
        return cloned;
      }
      return obj;
    }

    /**
     * 배열 중복 제거
     * @param {Array} array - 배열
     * @returns {Array} 중복이 제거된 배열
     *
     * @example
     * Utils.unique([1, 2, 2, 3]); // [1, 2, 3]
     */
    static unique(array) {
      return [...new Set(array)];
    }

    /**
     * 배열 평탄화
     * @param {Array} array - 배열
     * @returns {Array} 평탄화된 배열
     *
     * @example
     * Utils.flatten([1, [2, [3, 4]]]); // [1, 2, 3, 4]
     */
    static flatten(array) {
      return array.reduce((acc, val) => Array.isArray(val) ? acc.concat(this.flatten(val)) : acc.concat(val), []);
    }

    /**
     * 디바운스 함수 생성
     * @param {Function} func - 디바운스할 함수
     * @param {number} wait - 대기 시간 (ms)
     * @returns {Function} 디바운스된 함수
     *
     * @example
     * const debouncedSearch = Utils.debounce(search, 300);
     */
    static debounce(func, wait) {
      let timeout;
      return function executedFunction() {
        for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          args[_key2] = arguments[_key2];
        }
        const context = this; // this 컨텍스트 유지
        const later = () => {
          clearTimeout(timeout);
          func.apply(context, args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
      };
    }

    /**
     * 스로틀 함수 생성
     * @param {Function} func - 스로틀할 함수
     * @param {number} limit - 제한 시간 (ms)
     * @returns {Function} 스로틀된 함수
     *
     * @example
     * const throttledScroll = Utils.throttle(onScroll, 100);
     */
    static throttle(func, limit) {
      let inThrottle;
      return function () {
        const context = this; // this 컨텍스트 유지
        if (!inThrottle) {
          for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
            args[_key3] = arguments[_key3];
          }
          func.apply(context, args);
          inThrottle = true;
          setTimeout(() => inThrottle = false, limit);
        }
      };
    }

    /**
     * 랜덤 ID 생성
     * @param {string} prefix - 접두사 (기본: 'id')
     * @returns {string} 랜덤 ID
     *
     * @example
     * Utils.randomId('user'); // 'user-abc123xyz'
     */
    static randomId() {
      let prefix = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'id';
      return `${prefix}-${Math.random().toString(36).substr(2, 9)}`;
    }

    /**
     * 랜덤 정수 생성
     * @param {number} min - 최소값
     * @param {number} max - 최대값
     * @returns {number} 랜덤 정수
     *
     * @example
     * Utils.randomInt(1, 100); // 1~100 사이의 랜덤 정수
     */
    static randomInt(min, max) {
      return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    /**
     * 배열 청크 분할
     * @param {Array} array - 배열
     * @param {number} size - 청크 크기
     * @returns {Array[]} 청크 배열
     *
     * @example
     * Utils.chunk([1, 2, 3, 4, 5], 2); // [[1, 2], [3, 4], [5]]
     */
    static chunk(array, size) {
      const chunks = [];
      for (let i = 0; i < array.length; i += size) {
        chunks.push(array.slice(i, i + size));
      }
      return chunks;
    }

    /**
     * 배열 범위 생성
     * @param {number} start - 시작값
     * @param {number} end - 종료값
     * @param {number} step - 증가값 (기본: 1)
     * @returns {Array} 범위 배열
     *
     * @example
     * Utils.range(1, 5); // [1, 2, 3, 4, 5]
     * Utils.range(0, 10, 2); // [0, 2, 4, 6, 8, 10]
     */
    static range(start, end) {
      let step = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
      const result = [];
      for (let i = start; i <= end; i += step) {
        result.push(i);
      }
      return result;
    }

    /**
     * 문자열 자르기 (말줄임표)
     * @param {string} str - 문자열
     * @param {number} maxLength - 최대 길이
     * @param {string} suffix - 접미사 (기본: '...')
     * @returns {string} 잘린 문자열
     *
     * @example
     * Utils.truncate('Hello World', 8); // 'Hello...'
     */
    static truncate(str, maxLength) {
      let suffix = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '...';
      if (!this.isString(str) || str.length <= maxLength) return str;
      return str.substring(0, maxLength - suffix.length) + suffix;
    }

    /**
     * 카멜케이스 변환
     * @param {string} str - 문자열
     * @returns {string} 카멜케이스 문자열
     *
     * @example
     * Utils.camelCase('hello-world'); // 'helloWorld'
     * Utils.camelCase('hello_world'); // 'helloWorld'
     */
    static camelCase(str) {
      return str.replace(/[-_](\w)/g, (_, c) => c.toUpperCase());
    }

    /**
     * 케밥케이스 변환
     * @param {string} str - 문자열
     * @returns {string} 케밥케이스 문자열
     *
     * @example
     * Utils.kebabCase('helloWorld'); // 'hello-world'
     */
    static kebabCase(str) {
      return str.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
    }

    /**
     * 첫 글자 대문자
     * @param {string} str - 문자열
     * @returns {string} 첫 글자가 대문자인 문자열
     *
     * @example
     * Utils.capitalize('hello'); // 'Hello'
     */
    static capitalize(str) {
      if (!this.isString(str) || str.length === 0) return str;
      return str.charAt(0).toUpperCase() + str.slice(1);
    }

    /**
     * 지연 실행 (Promise)
     * @param {number} ms - 지연 시간 (ms)
     * @returns {Promise<void>}
     *
     * @example
     * await Utils.sleep(1000); // 1초 대기
     */
    static sleep(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }

    /**
     * 객체에서 특정 키만 선택
     * @param {Object} obj - 객체
     * @param {string[]} keys - 선택할 키 배열
     * @returns {Object} 선택된 키만 포함하는 객체
     *
     * @example
     * Utils.pick({ a: 1, b: 2, c: 3 }, ['a', 'c']); // { a: 1, c: 3 }
     */
    static pick(obj, keys) {
      const result = {};
      keys.forEach(key => {
        if (key in obj) {
          result[key] = obj[key];
        }
      });
      return result;
    }

    /**
     * 객체에서 특정 키 제거
     * @param {Object} obj - 객체
     * @param {string[]} keys - 제거할 키 배열
     * @returns {Object} 키가 제거된 객체
     *
     * @example
     * Utils.omit({ a: 1, b: 2, c: 3 }, ['b']); // { a: 1, c: 3 }
     */
    static omit(obj, keys) {
      const result = {
        ...obj
      };
      keys.forEach(key => {
        delete result[key];
      });
      return result;
    }
  }

  /**
   * 템플릿 엔진
   * @module core/template
   */

  /**
   * 간단하고 빠른 템플릿 엔진
   * @class
   * @description {{key}} 문법을 사용하는 간단한 템플릿 엔진입니다.
   * 자동 XSS 방어(이스케이프)를 제공하며, 조건부/리스트 렌더링을 지원합니다.
   *
   * @example
   * const html = Template.render('Hello {{name}}!', { name: 'John' });
   */
  class Template {
    /**
     * 템플릿 렌더링 (자동 XSS 방어)
     * @param {string} template - 템플릿 문자열 ({{key}} 형식)
     * @param {Object} [data={}] - 데이터 객체
     * @returns {string} 렌더링된 HTML
     *
     * @example
     * const html = Template.render('Hello {{name}}!', { name: 'John' });
     * // 'Hello John!'
     *
     * @example
     * // XSS 자동 방어
     * const html = Template.render('{{userInput}}', {
     *   userInput: '<script>alert("XSS")</script>'
     * });
     * // '&lt;script&gt;alert("XSS")&lt;/script&gt;'
     */
    static render(template) {
      let data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      if (typeof template !== 'string') {
        return '';
      }

      // {{key}} 형식의 플레이스홀더를 데이터로 치환
      return template.replace(/\{\{(\w+)\}\}/g, (match, key) => {
        const value = data[key];

        // undefined/null은 빈 문자열로
        if (value === undefined || value === null) {
          return '';
        }

        // 자동 이스케이프 (XSS 방어)
        return this._escape(String(value));
      });
    }

    /**
     * 안전하지 않은 렌더링 (이스케이프 없음)
     * 신뢰할 수 있는 HTML만 사용!
     * @param {string} template - 템플릿 문자열
     * @param {Object} [data={}] - 데이터 객체
     * @returns {string} 렌더링된 HTML
     *
     * @example
     * const html = Template.renderRaw('{{content}}', {
     *   content: '<b>Bold</b>'
     * });
     * // '<b>Bold</b>'
     */
    static renderRaw(template) {
      let data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      if (typeof template !== 'string') {
        return '';
      }
      return template.replace(/\{\{(\w+)\}\}/g, (match, key) => {
        const value = data[key];
        return value !== undefined && value !== null ? String(value) : '';
      });
    }

    /**
     * 조건부 렌더링
     * @param {boolean} condition - 조건
     * @param {string} template - 템플릿 문자열
     * @param {Object} [data={}] - 데이터 객체
     * @returns {string} 렌더링된 HTML 또는 빈 문자열
     *
     * @example
     * const html = Template.if(user.isAdmin, '<button>Admin Panel</button>', user);
     *
     * @example
     * const html = Template.if(false, '<button>Hidden</button>');
     * // ''
     */
    static if(condition, template) {
      let data = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return condition ? this.render(template, data) : '';
    }

    /**
     * 리스트 렌더링
     * @param {Array} items - 아이템 배열
     * @param {string} template - 각 아이템의 템플릿
     * @returns {string} 렌더링된 HTML
     *
     * @example
     * const users = [
     *   { name: 'John', age: 30 },
     *   { name: 'Jane', age: 25 }
     * ];
     *
     * const html = Template.each(users, '<li>{{name}} ({{age}})</li>');
     * // '<li>John (30)</li><li>Jane (25)</li>'
     */
    static each(items, template) {
      if (!Array.isArray(items) || items.length === 0) {
        return '';
      }
      return items.map(item => this.render(template, item)).join('');
    }

    /**
     * 템플릿 컴파일 (재사용을 위한 함수 생성)
     * @param {string} template - 템플릿 문자열
     * @returns {Function} 렌더링 함수
     *
     * @example
     * const greeting = Template.compile('Hello {{name}}!');
     * greeting({ name: 'John' }); // 'Hello John!'
     * greeting({ name: 'Jane' }); // 'Hello Jane!'
     *
     * @performance
     * - 같은 템플릿을 여러 번 사용할 경우 compile()로 최적화
     * - 정규표현식이 매번 실행되지만, 간단한 패턴이므로 충분히 빠름
     * - 복잡한 템플릿 엔진이 필요하면 Handlebars, Mustache 권장
     */
    static compile(template) {
      var _this = this;
      return function () {
        let data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        return _this.render(template, data);
      };
    }

    /**
     * HTML 이스케이프 (내부용)
     * @private
     * @param {string} str - 문자열
     * @returns {string} 이스케이프된 문자열
     */
    static _escape(str) {
      const div = document.createElement('div');
      div.textContent = str;
      return div.innerHTML;
    }
  }

  /**
   * Storage Module - localStorage/sessionStorage 래퍼
   * @module core/storage
   */

  /**
   * Storage 유틸리티
   * @class
   * @description localStorage/sessionStorage를 편리하게 사용할 수 있는 래퍼 클래스입니다.
   * 자동 직렬화/역직렬화, TTL(만료 시간) 지원을 제공합니다.
   *
   * @example
   * Storage.set('user', { name: 'John' });
   * const user = Storage.get('user');
   */
  class Storage {
    /**
     * 값 저장
     * @param {string} key - 키
     * @param {*} value - 값 (자동으로 JSON 직렬화)
     * @param {Object} [options={}] - 옵션
     * @param {number} [options.expires] - 만료 시간 (초)
     * @param {string} [options.storage='local'] - 'local' 또는 'session'
     * @returns {boolean} 성공 여부
     *
     * @example
     * Storage.set('user', { id: 1, name: 'John' });
     * Storage.set('token', 'abc123', { expires: 3600 }); // 1시간 후 만료
     * Storage.set('temp', 'data', { storage: 'session' }); // sessionStorage
     */
    static set(key, value) {
      let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      if (!key || typeof key !== 'string') {
        console.error('Storage.set: key must be a non-empty string');
        return false;
      }
      try {
        const storage = options.storage === 'session' ? sessionStorage : localStorage;
        const data = {
          value,
          timestamp: Date.now()
        };

        // 만료 시간 설정
        if (options.expires && typeof options.expires === 'number') {
          data.expires = Date.now() + options.expires * 1000;
        }
        storage.setItem(key, JSON.stringify(data));
        return true;
      } catch (error) {
        console.error('Storage.set error:', error);
        return false;
      }
    }

    /**
     * 값 가져오기
     * @param {string} key - 키
     * @param {*} [defaultValue] - 기본값 (없거나 만료된 경우 반환)
     * @param {string} [storage='local'] - 'local' 또는 'session'
     * @returns {*} 저장된 값 또는 기본값
     *
     * @example
     * const user = Storage.get('user');
     * const count = Storage.get('count', 0); // 없으면 0 반환
     */
    static get(key) {
      let defaultValue = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
      let storage = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'local';
      if (!key || typeof key !== 'string') {
        return defaultValue;
      }
      try {
        const storageObj = storage === 'session' ? sessionStorage : localStorage;
        const item = storageObj.getItem(key);
        if (!item) {
          return defaultValue;
        }
        const data = JSON.parse(item);

        // 만료 확인
        if (data.expires && Date.now() > data.expires) {
          this.remove(key, storage);
          return defaultValue;
        }
        return data.value;
      } catch (error) {
        console.error('Storage.get error:', error);
        return defaultValue;
      }
    }

    /**
     * 값 존재 확인
     * @param {string} key - 키
     * @param {string} [storage='local'] - 'local' 또는 'session'
     * @returns {boolean} 존재 여부
     *
     * @example
     * if (Storage.has('token')) {
     *   // 토큰이 있음
     * }
     */
    static has(key) {
      let storage = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'local';
      if (!key || typeof key !== 'string') {
        return false;
      }
      try {
        const storageObj = storage === 'session' ? sessionStorage : localStorage;
        const item = storageObj.getItem(key);
        if (!item) {
          return false;
        }
        const data = JSON.parse(item);

        // 만료 확인
        if (data.expires && Date.now() > data.expires) {
          this.remove(key, storage);
          return false;
        }
        return true;
      } catch (error) {
        return false;
      }
    }

    /**
     * 값 제거
     * @param {string} key - 키
     * @param {string} [storage='local'] - 'local' 또는 'session'
     * @returns {boolean} 성공 여부
     *
     * @example
     * Storage.remove('token');
     */
    static remove(key) {
      let storage = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'local';
      if (!key || typeof key !== 'string') {
        return false;
      }
      try {
        const storageObj = storage === 'session' ? sessionStorage : localStorage;
        storageObj.removeItem(key);
        return true;
      } catch (error) {
        console.error('Storage.remove error:', error);
        return false;
      }
    }

    /**
     * 모든 값 제거
     * @param {string} [storage='local'] - 'local' 또는 'session'
     * @returns {boolean} 성공 여부
     *
     * @example
     * Storage.clear(); // localStorage 전체 삭제
     * Storage.clear('session'); // sessionStorage 전체 삭제
     */
    static clear() {
      let storage = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'local';
      try {
        const storageObj = storage === 'session' ? sessionStorage : localStorage;
        storageObj.clear();
        return true;
      } catch (error) {
        console.error('Storage.clear error:', error);
        return false;
      }
    }

    /**
     * 모든 키 목록 가져오기
     * @param {string} [storage='local'] - 'local' 또는 'session'
     * @returns {string[]} 키 배열
     *
     * @example
     * const keys = Storage.keys(); // ['user', 'token', ...]
     */
    static keys() {
      let storage = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'local';
      try {
        const storageObj = storage === 'session' ? sessionStorage : localStorage;
        return Object.keys(storageObj);
      } catch (error) {
        console.error('Storage.keys error:', error);
        return [];
      }
    }

    /**
     * 스토리지 크기 확인 (대략적)
     * @param {string} [storage='local'] - 'local' 또는 'session'
     * @returns {number} 사용 중인 바이트 수 (근사값)
     *
     * @example
     * const size = Storage.size(); // 1024 (bytes)
     */
    static size() {
      let storage = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'local';
      try {
        const storageObj = storage === 'session' ? sessionStorage : localStorage;
        let total = 0;
        for (let i = 0; i < storageObj.length; i++) {
          const key = storageObj.key(i);
          const value = storageObj.getItem(key);
          if (key && value) {
            total += key.length + value.length;
          }
        }
        return total * 2; // UTF-16이므로 2배
      } catch (error) {
        console.error('Storage.size error:', error);
        return 0;
      }
    }

    /**
     * 만료된 항목 제거
     * @param {string} [storage='local'] - 'local' 또는 'session'
     * @returns {number} 제거된 항목 수
     *
     * @example
     * const removed = Storage.cleanExpired(); // 만료된 항목 삭제
     */
    static cleanExpired() {
      let storage = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'local';
      try {
        const storageObj = storage === 'session' ? sessionStorage : localStorage;
        const keys = Object.keys(storageObj);
        let removed = 0;
        keys.forEach(key => {
          try {
            const item = storageObj.getItem(key);
            if (item) {
              const data = JSON.parse(item);
              if (data.expires && Date.now() > data.expires) {
                storageObj.removeItem(key);
                removed++;
              }
            }
          } catch (e) {
            // JSON 파싱 실패는 무시
          }
        });
        return removed;
      } catch (error) {
        console.error('Storage.cleanExpired error:', error);
        return 0;
      }
    }
  }

  /**
   * URL & Query String 유틸리티
   * @module core/url
   */

  /**
   * URL 파싱 및 빌딩 유틸리티
   * @class
   * @description URL 과 쿠리 스트링을 파싱하고 조작하는 유틸리티 클래스입니다.
   * URLSearchParams를 래핑하여 편리한 API를 제공합니다.
   *
   * @example
   * const params = URLUtil.parse('?id=1&name=John');
   * const query = URLUtil.stringify({ id: 1, name: 'John' });
   */
  class URLUtil {
    /**
     * 쿼리 스트링 파싱
     * @param {string} [queryString] - 쿼리 스트링 (없으면 현재 URL 사용)
     * @returns {Object} 파싱된 객체
     *
     * @example
     * const params = URLUtil.parseQuery('?page=1&sort=name');
     * // { page: '1', sort: 'name' }
     *
     * @example
     * const params = URLUtil.parseQuery(); // 현재 URL의 쿼리 파싱
     */
    static parseQuery(queryString) {
      const query = queryString || window.location.search;
      const params = {};
      if (!query) return params;

      // ? 제거
      const cleaned = query.startsWith('?') ? query.slice(1) : query;
      if (!cleaned) return params;

      // & 로 분리하여 파싱
      cleaned.split('&').forEach(pair => {
        const [key, value] = pair.split('=');
        if (key) {
          const decodedKey = decodeURIComponent(key);
          const decodedValue = value ? decodeURIComponent(value) : '';

          // 배열 처리 (key[])
          if (decodedKey.endsWith('[]')) {
            const arrayKey = decodedKey.slice(0, -2);
            if (!params[arrayKey]) {
              params[arrayKey] = [];
            }
            params[arrayKey].push(decodedValue);
          } else {
            params[decodedKey] = decodedValue;
          }
        }
      });
      return params;
    }

    /**
     * 쿼리 스트링 빌딩
     * @param {Object} params - 파라미터 객체
     * @param {boolean} [includeQuestion=true] - ? 포함 여부
     * @returns {string} 쿼리 스트링
     *
     * @example
     * const query = URLUtil.buildQuery({ page: 2, sort: 'name' });
     * // '?page=2&sort=name'
     *
     * @example
     * const query = URLUtil.buildQuery({ tags: ['js', 'css'] });
     * // '?tags[]=js&tags[]=css'
     */
    static buildQuery(params) {
      let includeQuestion = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      if (!params || typeof params !== 'object') {
        return includeQuestion ? '?' : '';
      }
      const pairs = [];
      Object.keys(params).forEach(key => {
        const value = params[key];
        if (value === null || value === undefined) {
          return; // skip
        }
        if (Array.isArray(value)) {
          // 배열 처리
          value.forEach(item => {
            pairs.push(`${encodeURIComponent(key)}[]=${encodeURIComponent(item)}`);
          });
        } else {
          pairs.push(`${encodeURIComponent(key)}=${encodeURIComponent(value)}`);
        }
      });
      const query = pairs.join('&');
      return query ? (includeQuestion ? '?' : '') + query : '';
    }

    /**
     * URL과 쿼리 파라미터 결합
     * @param {string} url - 기본 URL
     * @param {Object} params - 파라미터 객체
     * @returns {string} 결합된 URL
     *
     * @example
     * const url = URLUtil.buildURL('/api/users', { page: 1, limit: 10 });
     * // '/api/users?page=1&limit=10'
     */
    static buildURL(url, params) {
      if (!params || Object.keys(params).length === 0) {
        return url;
      }
      const query = this.buildQuery(params, false);
      if (!query) return url;

      // 이미 쿼리 스트링이 있는 경우
      if (url.includes('?')) {
        return `${url}&${query}`;
      }
      return `${url}?${query}`;
    }

    /**
     * 현재 URL에 파라미터 추가/업데이트 (히스토리 없이)
     * @param {Object} params - 추가할 파라미터
     * @param {boolean} [replace=false] - replace 모드 (기존 파라미터 유지 여부)
     *
     * @example
     * // 현재 URL: /page?foo=bar
     * URLUtil.updateQuery({ page: 2 });
     * // 결과: /page?foo=bar&page=2
     *
     * @example
     * URLUtil.updateQuery({ page: 2 }, true); // replace 모드
     * // 결과: /page?page=2
     */
    static updateQuery(params) {
      let replace = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      const currentParams = replace ? {} : this.parseQuery();
      const newParams = {
        ...currentParams,
        ...params
      };
      const query = this.buildQuery(newParams);
      const newURL = window.location.pathname + query;
      window.history.replaceState({}, '', newURL);
    }

    /**
     * 특정 쿼리 파라미터 가져오기
     * @param {string} key - 파라미터 키
     * @param {*} [defaultValue] - 기본값
     * @returns {*} 파라미터 값
     *
     * @example
     * // 현재 URL: /page?id=123&name=John
     * const id = URLUtil.getParam('id'); // '123'
     * const age = URLUtil.getParam('age', 0); // 0 (기본값)
     */
    static getParam(key) {
      let defaultValue = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
      const params = this.parseQuery();
      return params[key] !== undefined ? params[key] : defaultValue;
    }

    /**
     * 특정 쿼리 파라미터 제거
     * @param {string|string[]} keys - 제거할 키 (배열 가능)
     *
     * @example
     * // 현재 URL: /page?id=123&name=John&age=30
     * URLUtil.removeParam('age');
     * // 결과: /page?id=123&name=John
     *
     * @example
     * URLUtil.removeParam(['id', 'age']);
     * // 결과: /page?name=John
     */
    static removeParam(keys) {
      const params = this.parseQuery();
      const keysToRemove = Array.isArray(keys) ? keys : [keys];
      keysToRemove.forEach(key => {
        delete params[key];
      });
      const query = this.buildQuery(params);
      const newURL = window.location.pathname + query;
      window.history.replaceState({}, '', newURL);
    }

    /**
     * 모든 쿼리 파라미터 제거
     *
     * @example
     * // 현재 URL: /page?id=123&name=John
     * URLUtil.clearQuery();
     * // 결과: /page
     */
    static clearQuery() {
      window.history.replaceState({}, '', window.location.pathname);
    }

    /**
     * URL 파싱 (전체)
     * @param {string} [url] - 파싱할 URL (없으면 현재 URL)
     * @returns {Object} 파싱된 URL 정보
     *
     * @example
     * const info = URLUtil.parse('https://example.com:8080/path?id=1#section');
     * // {
     * //   protocol: 'https:',
     * //   host: 'example.com:8080',
     * //   hostname: 'example.com',
     * //   port: '8080',
     * //   pathname: '/path',
     * //   search: '?id=1',
     * //   hash: '#section',
     * //   query: { id: '1' }
     * // }
     */
    static parse(url) {
      const urlObj = url ? new URL(url, window.location.origin) : window.location;
      return {
        protocol: urlObj.protocol,
        host: urlObj.host,
        hostname: urlObj.hostname,
        port: urlObj.port,
        pathname: urlObj.pathname,
        search: urlObj.search,
        hash: urlObj.hash,
        query: this.parseQuery(urlObj.search)
      };
    }
  }

  /**
   * State Management - 리액티브 상태 관리
   * @module core/state
   */

  /**
   * 리액티브 상태 관리 클래스
   * @class
   * @description 리액티브 상태 관리를 제공하는 클래스입니다.
   * watch, computed 등의 기능으로 상태 변화를 감지하고 자동 UI 업데이트를 지원합니다.
   *
   * @example
   * const manager = new StateManager();
   * const state = manager.create({ count: 0 });
   */
  class StateManager {
    /**
     * 상태 스토어 생성
     * @param {Object} initialState - 초기 상태
     * @returns {Proxy} 리액티브 상태 객체
     *
     * @example
     * const store = StateManager.create({
     *   count: 0,
     *   user: null
     * });
     *
     * // 상태 변경 감지
     * store.watch('count', (newValue, oldValue) => {
     *   console.log(`count: ${oldValue} -> ${newValue}`);
     * });
     *
     * store.count++; // 자동으로 감지됨
     */
    static create() {
      let initialState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      const state = new StateStore(initialState);
      return state.getProxy();
    }
  }

  /**
   * 상태 스토어 내부 클래스
   * @class
   * @private
   * @description 상태를 저장하고 관리하는 내부 클래스입니다.
   */
  class StateStore {
    /**
     * StateStore 생성자
     * @constructor
     * @param {Object} initialState - 초기 상태
     */
    constructor(initialState) {
      this._state = {
        ...initialState
      };
      this._watchers = new Map(); // key -> [callback, callback, ...]
      this._computedCache = new Map();
      this._computedDeps = new Map();
      this._isUpdating = false;
      this._batchedUpdates = [];
    }

    /**
     * 리액티브 프록시 생성
     */
    getProxy() {
      const self = this;
      const proxy = new Proxy(this._state, {
        get(target, property) {
          // 내부 메서드 접근
          if (property === '_store') return self;
          if (property === 'watch') return self.watch.bind(self);
          if (property === 'unwatch') return self.unwatch.bind(self);
          if (property === 'compute') return self.compute.bind(self);
          if (property === 'batch') return self.batch.bind(self);
          if (property === 'getState') return self.getState.bind(self);
          if (property === 'setState') return self.setState.bind(self);
          if (property === 'reset') return self.reset.bind(self);
          if (property === 'destroy') return self.destroy.bind(self);
          return target[property];
        },
        set(target, property, value) {
          const oldValue = target[property];

          // 값이 같으면 무시
          if (oldValue === value) return true;

          // 상태 업데이트
          target[property] = value;

          // 배치 모드가 아니면 즉시 알림
          if (!self._isUpdating) {
            self._notifyWatchers(property, value, oldValue);
          } else {
            // 배치 모드면 대기열에 추가
            self._batchedUpdates.push({
              property,
              value,
              oldValue
            });
          }
          return true;
        }
      });
      return proxy;
    }

    /**
     * 상태 변경 감시
     * @param {string} key - 감시할 키
     * @param {Function} callback - 콜백 (newValue, oldValue)
     * @returns {Function} 구독 취소 함수
     */
    watch(key, callback) {
      if (!this._watchers.has(key)) {
        this._watchers.set(key, []);
      }
      this._watchers.get(key).push(callback);

      // 구독 취소 함수 반환
      return () => this.unwatch(key, callback);
    }

    /**
     * 감시 취소
     * @param {string} key - 키
     * @param {Function} [callback] - 콜백 (없으면 모두 제거)
     */
    unwatch(key, callback) {
      if (!this._watchers.has(key)) return;
      if (callback) {
        const callbacks = this._watchers.get(key);
        const index = callbacks.indexOf(callback);
        if (index !== -1) {
          callbacks.splice(index, 1);
        }

        // 콜백이 없으면 키 제거
        if (callbacks.length === 0) {
          this._watchers.delete(key);
        }
      } else {
        // 모든 콜백 제거
        this._watchers.delete(key);
      }
    }

    /**
     * 계산된 속성 (computed property)
     * @param {string} key - 키
     * @param {Function} getter - 계산 함수
     * @returns {*} 계산된 값
     *
     * @example
     * store.compute('fullName', () => {
     *   return `${store.firstName} ${store.lastName}`;
     * });
     */
    compute(key, getter) {
      const self = this;

      // 의존성 추적
      const deps = this._trackDependencies(getter);
      this._computedDeps.set(key, deps);

      // 의존성 변경 시 캐시 무효화
      deps.forEach(dep => {
        this.watch(dep, () => {
          this._computedCache.delete(key);
        });
      });

      // getter를 상태에 추가
      Object.defineProperty(this._state, key, {
        get: () => {
          if (self._computedCache.has(key)) {
            return self._computedCache.get(key);
          }

          // getter를 state 컨텍스트로 실행
          const value = getter.call(self._state);
          self._computedCache.set(key, value);
          return value;
        },
        enumerable: true,
        configurable: true
      });
      return this._state[key];
    }

    /**
     * 의존성 추적 (간단한 구현)
     * @private
     */
    _trackDependencies(getter) {
      const deps = new Set();
      const proxy = new Proxy(this._state, {
        get(target, property) {
          deps.add(property);
          return target[property];
        }
      });

      // getter 실행하여 의존성 수집
      try {
        getter.call(proxy);
      } catch (e) {
        // 에러 무시 (의존성만 수집)
      }
      return Array.from(deps);
    }

    /**
     * 배치 업데이트 (여러 변경을 한 번에)
     * @param {Function} fn - 업데이트 함수
     *
     * @example
     * store.batch(() => {
     *   store.count++;
     *   store.name = 'John';
     *   store.age = 30;
     * }); // 모든 변경 후 한 번만 알림
     */
    batch(fn) {
      this._isUpdating = true;
      this._batchedUpdates = [];
      try {
        fn();
      } finally {
        this._isUpdating = false;

        // 배치된 업데이트 알림
        this._batchedUpdates.forEach(_ref => {
          let {
            property,
            value,
            oldValue
          } = _ref;
          this._notifyWatchers(property, value, oldValue);
        });
        this._batchedUpdates = [];
      }
    }

    /**
     * 전체 상태 가져오기
     * @returns {Object} 상태 복사본
     */
    getState() {
      return {
        ...this._state
      };
    }

    /**
     * 전체 상태 설정
     * @param {Object} newState - 새 상태
     * @param {boolean} [merge=true] - 병합 여부
     */
    setState(newState) {
      let merge = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      this.batch(() => {
        if (merge) {
          Object.keys(newState).forEach(key => {
            this._state[key] = newState[key];
          });
        } else {
          // 전체 교체
          Object.keys(this._state).forEach(key => {
            if (!(key in newState)) {
              delete this._state[key];
            }
          });
          Object.keys(newState).forEach(key => {
            this._state[key] = newState[key];
          });
        }
      });
    }

    /**
     * 초기 상태로 리셋
     * @param {Object} [initialState] - 새 초기 상태 (없으면 빈 객체)
     */
    reset() {
      let initialState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      this.setState(initialState, false);
    }

    /**
     * 감시자에게 알림
     * @private
     */
    _notifyWatchers(key, newValue, oldValue) {
      if (!this._watchers.has(key)) return;
      const callbacks = this._watchers.get(key);
      callbacks.forEach(callback => {
        try {
          callback(newValue, oldValue);
        } catch (error) {
          console.error(`Error in watcher for "${key}":`, error);
        }
      });
    }

    /**
     * 상태 스토어 정리 (메모리 누수 방지)
     * 모든 watcher와 computed 속성을 제거합니다.
     *
     * @example
     * const state = StateManager.create({ count: 0 });
     * state.watch('count', handler);
     * // 사용 종료 시
     * state.destroy();
     */
    destroy() {
      // 모든 watcher 제거
      this._watchers.clear();

      // computed 캐시 및 의존성 제거
      this._computedCache.clear();
      this._computedDeps.clear();

      // 배치 업데이트 큐 정리
      this._batchedUpdates = [];
      this._isUpdating = false;

      // 상태 초기화
      this._state = {};
    }
  }

  /**
   * 전역 상태 스토어 (옵션)
   * @class
   * @description 앱 전체에서 공유하는 전역 상태를 관리합니다.
   * 여러 컴포넌트간 상태를 공유할 때 사용합니다.
   *
   * @example
   * GlobalState.set('user', { name: 'John' });
   * const user = GlobalState.get('user');
   */
  class GlobalState {
    /**
     * 전역 스토어 생성 또는 가져오기
     * @param {string} name - 스토어 이름
     * @param {Object} [initialState] - 초기 상태
     * @returns {Proxy} 스토어
     *
     * @example
     * const userStore = GlobalState.use('user', { id: null, name: '' });
     * const appStore = GlobalState.use('app', { theme: 'light' });
     */
    static use(name) {
      let initialState = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      if (!this._stores.has(name)) {
        this._stores.set(name, StateManager.create(initialState));
      }
      return this._stores.get(name);
    }

    /**
     * 전역 스토어 제거
     * @param {string} name - 스토어 이름
     */
    static remove(name) {
      const store = this._stores.get(name);
      if (store && typeof store.destroy === 'function') {
        store.destroy();
      }
      this._stores.delete(name);
    }

    /**
     * 모든 전역 스토어 제거
     */
    static clear() {
      // 모든 스토어의 destroy() 호출
      this._stores.forEach(store => {
        if (store && typeof store.destroy === 'function') {
          store.destroy();
        }
      });
      this._stores.clear();
    }
  }
  _defineProperty(GlobalState, "_stores", new Map());

  /**
   * Form Validation Module
   * @module core/form
   */

  /**
   * 폼 검증 유틸리티
   * @class
   * @description 폼 입력 값의 검증을 수행하는 클래스입니다.
   * 다양한 검증 규칙(required, email, min, max 등)을 제공합니다.
   *
   * @example
   * const validator = new FormValidator('#myForm', {
   *   rules: { email: ['required', 'email'] }
   * });
   */
  class FormValidator {
    /**
     * 폼 검증기 생성
     * @param {string|HTMLElement} form - 폼 선택자 또는 요소
     * @param {Object} rules - 검증 규칙
     * @param {Object} [options={}] - 옵션
     * @returns {FormValidator} 검증기 인스턴스
     *
     * @example
     * const validator = FormValidator.create('#login-form', {
     *   email: { required: true, email: true },
     *   password: { required: true, minLength: 8 }
     * });
     */
    static create(form, rules) {
      let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return new FormValidator(form, rules, options);
    }
    constructor(_form, rules) {
      let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      /**
       * 기본 검증 규칙
       */
      _defineProperty(this, "validators", {
        required: {
          validate: value => ({
            valid: value !== null && value !== undefined && value.trim() !== '',
            message: '필수 입력 항목입니다.'
          })
        },
        email: {
          validate: value => {
            if (!value) return {
              valid: true
            };
            const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return {
              valid: regex.test(value),
              message: '올바른 이메일 형식이 아닙니다.'
            };
          }
        },
        minLength: {
          validate: (value, min) => ({
            valid: !value || value.length >= min,
            message: `최소 ${min}자 이상 입력해주세요.`
          })
        },
        maxLength: {
          validate: (value, max) => ({
            valid: !value || value.length <= max,
            message: `최대 ${max}자까지 입력 가능합니다.`
          })
        },
        min: {
          validate: (value, min) => {
            if (!value) return {
              valid: true
            };
            const num = Number(value);
            return {
              valid: !isNaN(num) && num >= min,
              message: `${min} 이상의 값을 입력해주세요.`
            };
          }
        },
        max: {
          validate: (value, max) => {
            if (!value) return {
              valid: true
            };
            const num = Number(value);
            return {
              valid: !isNaN(num) && num <= max,
              message: `${max} 이하의 값을 입력해주세요.`
            };
          }
        },
        pattern: {
          validate: (value, pattern) => {
            if (!value) return {
              valid: true
            };
            const regex = typeof pattern === 'string' ? new RegExp(pattern) : pattern;
            return {
              valid: regex.test(value),
              message: '입력 형식이 올바르지 않습니다.'
            };
          }
        },
        number: {
          validate: value => {
            if (!value || value.trim() === '') return {
              valid: true
            };
            return {
              valid: !isNaN(Number(value)) && value.trim() !== '',
              message: '숫자만 입력 가능합니다.'
            };
          }
        },
        url: {
          validate: value => {
            if (!value) return {
              valid: true
            };
            try {
              new URL(value);
              return {
                valid: true
              };
            } catch {
              return {
                valid: false,
                message: '올바른 URL 형식이 아닙니다.'
              };
            }
          }
        },
        match: {
          validate: (value, targetFieldName, form) => {
            if (!value) return {
              valid: true
            };
            const targetField = form.elements[targetFieldName];
            return {
              valid: targetField && value === targetField.value,
              message: '입력값이 일치하지 않습니다.'
            };
          }
        },
        custom: {
          validate: (value, fn) => {
            const result = fn(value);
            if (typeof result === 'boolean') {
              return {
                valid: result,
                message: '유효하지 않은 값입니다.'
              };
            }
            return result;
          }
        }
      });
      this.form = typeof _form === 'string' ? document.querySelector(_form) : _form;
      this.rules = rules;
      this.options = {
        validateOnBlur: true,
        validateOnInput: false,
        errorClass: 'is-invalid',
        successClass: 'is-valid',
        errorMessageClass: 'error-message',
        showErrorMessages: true,
        ...options
      };
      this.errors = {};
      this.touched = {};
      this._eventHandlers = [];
      this._init();
    }

    /**
     * 초기화
     * @private
     */
    _init() {
      if (!this.form) return;

      // 각 필드에 이벤트 리스너 추가
      Object.keys(this.rules).forEach(fieldName => {
        const field = this.form.elements[fieldName];
        if (!field) return;
        if (this.options.validateOnBlur) {
          const blurHandler = () => this._validateField(fieldName);
          field.addEventListener('blur', blurHandler);
          this._eventHandlers.push({
            element: field,
            event: 'blur',
            handler: blurHandler
          });
        }
        if (this.options.validateOnInput) {
          const inputHandler = () => this._validateField(fieldName);
          field.addEventListener('input', inputHandler);
          this._eventHandlers.push({
            element: field,
            event: 'input',
            handler: inputHandler
          });
        }
      });

      // 폼 제출 이벤트
      const submitHandler = e => {
        if (!this.validate()) {
          e.preventDefault();
        }
      };
      this.form.addEventListener('submit', submitHandler);
      this._eventHandlers.push({
        element: this.form,
        event: 'submit',
        handler: submitHandler
      });
    }

    /**
     * 단일 필드 검증
     * @param {string} fieldName - 필드 이름
     * @returns {boolean} 검증 성공 여부
     */
    _validateField(fieldName) {
      const field = this.form.elements[fieldName];
      if (!field) return true;
      const rules = this.rules[fieldName];
      const value = field.value;
      this.touched[fieldName] = true;

      // 모든 규칙 검사
      for (const [ruleName, ruleValue] of Object.entries(rules)) {
        const validator = this.validators[ruleName];
        if (!validator) continue;
        const result = validator.validate(value, ruleValue, this.form);
        if (!result.valid) {
          this.errors[fieldName] = result.message;
          this._updateFieldUI(field, false, result.message);
          return false;
        }
      }

      // 모든 규칙 통과
      delete this.errors[fieldName];
      this._updateFieldUI(field, true);
      return true;
    }

    /**
     * 전체 폼 검증
     * @returns {boolean} 검증 성공 여부
     */
    validate() {
      let isValid = true;
      Object.keys(this.rules).forEach(fieldName => {
        if (!this._validateField(fieldName)) {
          isValid = false;
        }
      });
      return isValid;
    }

    /**
     * 필드 UI 업데이트
     * @private
     */
    _updateFieldUI(field, isValid) {
      let errorMessage = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
      // 클래스 업데이트
      field.classList.remove(this.options.errorClass, this.options.successClass);
      field.classList.add(isValid ? this.options.successClass : this.options.errorClass);

      // 에러 메시지 표시
      if (this.options.showErrorMessages) {
        let errorEl = field.parentElement.querySelector(`.${this.options.errorMessageClass}`);
        if (!isValid && errorMessage) {
          if (!errorEl) {
            errorEl = document.createElement('div');
            errorEl.className = this.options.errorMessageClass;
            field.parentElement.appendChild(errorEl);
          }
          errorEl.textContent = errorMessage;
          errorEl.style.display = 'block';
        } else if (errorEl) {
          errorEl.style.display = 'none';
        }
      }
    }

    /**
     * 에러 목록 가져오기
     * @returns {Object} 에러 객체
     */
    getErrors() {
      return {
        ...this.errors
      };
    }

    /**
     * 특정 필드의 에러 가져오기
     * @param {string} fieldName - 필드 이름
     * @returns {string|null} 에러 메시지
     */
    getError(fieldName) {
      return this.errors[fieldName] || null;
    }

    /**
     * 검증 성공 여부
     * @returns {boolean}
     */
    isValid() {
      return Object.keys(this.errors).length === 0;
    }

    /**
     * 폼 리셋
     */
    reset() {
      this.errors = {};
      this.touched = {};
      if (this.form) {
        this.form.reset();

        // UI 초기화
        Object.keys(this.rules).forEach(fieldName => {
          const field = this.form.elements[fieldName];
          if (field) {
            field.classList.remove(this.options.errorClass, this.options.successClass);
            const errorEl = field.parentElement.querySelector(`.${this.options.errorMessageClass}`);
            if (errorEl) {
              errorEl.style.display = 'none';
            }
          }
        });
      }
    }

    /**
     * 이벤트 리스너 정리
     */
    destroy() {
      this._eventHandlers.forEach(_ref => {
        let {
          element,
          event,
          handler
        } = _ref;
        element.removeEventListener(event, handler);
      });
      this._eventHandlers = [];
    }
    /**
     * 커스텀 검증 규칙 추가
     * @param {string} name - 규칙 이름
     * @param {Function} validator - 검증 함수
     */
    addValidator(name, validator) {
      this.validators[name] = validator;
    }
  }

  var _AnimationUtil;
  /**
   * Animation Utilities - 다양한 애니메이션 효과
   * @module core/animation
   */

  /**
   * 애니메이션 유틸리티
   * @class
   * @description Web Animations API 기반의 다양한 애니메이션 효과를 제공합니다.
   * GPU 가속을 활용하여 부드러운 60fps 애니메이션을 구현합니다.
   *
   * @example
   * // Fade In 애니메이션
   * await AnimationUtil.animate('#box').fadeIn(300);
   *
   * @example
   * // Bounce In 애니메이션
   * await AnimationUtil.animate('.card').bounceIn(600);
   */
  class AnimationUtil {
    /**
     * 애니메이션 생성
     * @param {string|HTMLElement} element - 대상 요소
     * @returns {Animator} 애니메이터 인스턴스
     *
     * @example
     * await AnimationUtil.animate('#box').fadeIn(300);
     * await AnimationUtil.animate('#box').slideDown(400);
     */
    static animate(element) {
      return new Animator(element);
    }

    /**
     * 이징 함수들
     */
  }

  /**
   * 애니메이터 클래스
   * @class
   * @description 개별 요소에 대한 애니메이션을 실행하는 클래스입니다.
   * 20가지 이상의 다양한 애니메이션 효과를 제공합니다.
   */
  _AnimationUtil = AnimationUtil;
  _defineProperty(AnimationUtil, "easings", {
    linear: t => t,
    easeIn: t => t * t,
    easeOut: t => t * (2 - t),
    easeInOut: t => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
    easeInCubic: t => t * t * t,
    easeOutCubic: t => --t * t * t + 1,
    easeInOutCubic: t => t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1,
    easeInQuart: t => t * t * t * t,
    easeOutQuart: t => 1 - --t * t * t * t,
    easeInOutQuart: t => t < 0.5 ? 8 * t * t * t * t : 1 - 8 * --t * t * t * t,
    easeInQuint: t => t * t * t * t * t,
    easeOutQuint: t => 1 + --t * t * t * t * t,
    easeInOutQuint: t => t < 0.5 ? 16 * t * t * t * t * t : 1 + 16 * --t * t * t * t * t,
    easeInElastic: t => t === 0 ? 0 : t === 1 ? 1 : -Math.pow(2, 10 * t - 10) * Math.sin((t * 10 - 10.75) * (2 * Math.PI / 3)),
    easeOutElastic: t => t === 0 ? 0 : t === 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI / 3)) + 1,
    easeInBounce: t => 1 - _AnimationUtil.easings.easeOutBounce(1 - t),
    easeOutBounce: t => {
      const n1 = 7.5625;
      const d1 = 2.75;
      if (t < 1 / d1) {
        return n1 * t * t;
      } else if (t < 2 / d1) {
        return n1 * (t -= 1.5 / d1) * t + 0.75;
      } else if (t < 2.5 / d1) {
        return n1 * (t -= 2.25 / d1) * t + 0.9375;
      } else {
        return n1 * (t -= 2.625 / d1) * t + 0.984375;
      }
    }
  });
  class Animator {
    /**
     * Animator 생성자
     * @constructor
     * @param {string|HTMLElement} element - 애니메이션을 적용할 대상 요소 (CSS 선택자 또는 DOM 요소)
     *
     * @example
     * const animator = new Animator('#myElement');
     *
     * @example
     * const animator = new Animator(document.getElementById('myElement'));
     */
    constructor(element) {
      this.element = typeof element === 'string' ? document.querySelector(element) : element;
    }

    /**
     * 커스텀 애니메이션
     * @param {Object} from - 시작 스타일
     * @param {Object} to - 종료 스타일
     * @param {number} duration - 지속 시간 (ms)
     * @param {string|Function} easing - 이징 함수
     * @returns {Promise}
     */
    custom(from, to) {
      let duration = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 300;
      let easing = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 'easeInOut';
      return new Promise(resolve => {
        if (!this.element) {
          resolve();
          return;
        }
        const easingFn = typeof easing === 'function' ? easing : AnimationUtil.easings[easing] || AnimationUtil.easings.linear;

        // 시작 스타일 적용 (다음 프레임에서)
        requestAnimationFrame(() => {
          Object.keys(from).forEach(key => {
            this.element.style[key] = from[key];
          });

          // 리플로우 강제 (브라우저가 from 스타일을 확실히 적용하도록)
          void this.element.offsetHeight;

          // 애니메이션 시작
          const startTime = performance.now();
          const animate = currentTime => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const easedProgress = easingFn(progress);

            // 스타일 보간
            Object.keys(to).forEach(key => {
              const fromValue = this._parseValue(from[key]);
              const toValue = this._parseValue(to[key]);
              if (fromValue.unit && toValue.unit) {
                const currentValue = fromValue.value + (toValue.value - fromValue.value) * easedProgress;
                this.element.style[key] = `${currentValue}${toValue.unit}`;
              } else {
                this.element.style[key] = to[key];
              }
            });
            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              resolve();
            }
          };
          requestAnimationFrame(animate);
        });
      });
    }

    /**
     * 값 파싱 (숫자 + 단위)
     * @private
     */
    _parseValue(value) {
      if (typeof value !== 'string') return {
        value,
        unit: ''
      };
      const match = value.match(/^([-+]?[\d.]+)([a-z%]*)$/i);
      if (match) {
        return {
          value: parseFloat(match[1]),
          unit: match[2] || ''
        };
      }
      return {
        value: 0,
        unit: ''
      };
    }

    /**
     * Fade In
     */
    fadeIn() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 300;
      let easing = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'ease-out';
      if (!this.element) return Promise.resolve();
      this.element.style.display = 'block';
      const keyframes = [{
        opacity: '0'
      }, {
        opacity: '1'
      }];
      const animation = this.element.animate(keyframes, {
        duration,
        easing,
        fill: 'forwards'
      });
      return animation.finished.then(() => {
        this.element.style.opacity = '1';
      });
    }

    /**
     * Fade Out
     */
    fadeOut() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 300;
      let easing = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'easeIn';
      return this.custom({
        opacity: '1'
      }, {
        opacity: '0'
      }, duration, easing).then(() => {
        if (this.element) this.element.style.display = 'none';
      });
    }

    /**
     * Slide Down
     */
    slideDown() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 400;
      let easing = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'easeOutCubic';
      if (!this.element) return Promise.resolve();
      const element = this.element;
      element.style.display = 'block';
      const height = element.scrollHeight;
      element.style.height = '0';
      element.style.overflow = 'hidden';
      return this.custom({
        height: '0px'
      }, {
        height: `${height}px`
      }, duration, easing).then(() => {
        element.style.height = '';
        element.style.overflow = '';
      });
    }

    /**
     * Slide Up
     */
    slideUp() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 400;
      let easing = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'easeInCubic';
      if (!this.element) return Promise.resolve();
      const element = this.element;
      const height = element.scrollHeight;
      element.style.height = `${height}px`;
      element.style.overflow = 'hidden';
      return this.custom({
        height: `${height}px`
      }, {
        height: '0px'
      }, duration, easing).then(() => {
        element.style.display = 'none';
        element.style.height = '';
        element.style.overflow = '';
      });
    }

    /**
     * Slide Left
     */
    slideLeft() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 400;
      let easing = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'easeInOut';
      if (!this.element) return Promise.resolve();
      const width = this.element.offsetWidth;
      return this.custom({
        transform: 'translateX(0)',
        opacity: '1'
      }, {
        transform: `translateX(-${width}px)`,
        opacity: '0'
      }, duration, easing).then(() => {
        if (this.element) this.element.style.display = 'none';
      });
    }

    /**
     * Slide Right
     */
    slideRight() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 400;
      let easing = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'easeInOut';
      if (!this.element) return Promise.resolve();
      const width = this.element.offsetWidth;
      return this.custom({
        transform: 'translateX(0)',
        opacity: '1'
      }, {
        transform: `translateX(${width}px)`,
        opacity: '0'
      }, duration, easing).then(() => {
        if (this.element) this.element.style.display = 'none';
      });
    }

    /**
     * Scale In
     */
    scaleIn() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 300;
      let easing = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'ease-out';
      if (!this.element) return Promise.resolve();
      this.element.style.display = 'block';
      const keyframes = [{
        transform: 'scale(0)',
        opacity: '0'
      }, {
        transform: 'scale(1)',
        opacity: '1'
      }];
      const animation = this.element.animate(keyframes, {
        duration,
        easing,
        fill: 'forwards'
      });
      return animation.finished.then(() => {
        this.element.style.transform = 'scale(1)';
        this.element.style.opacity = '1';
      });
    }

    /**
     * Scale Out
     */
    scaleOut() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 300;
      let easing = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'easeInCubic';
      return this.custom({
        transform: 'scale(1)',
        opacity: '1'
      }, {
        transform: 'scale(0)',
        opacity: '0'
      }, duration, easing).then(() => {
        if (this.element) this.element.style.display = 'none';
      });
    }

    /**
     * Bounce In
     */
    bounceIn() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 600;
      let easing = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'cubic-bezier(0.68, -0.55, 0.265, 1.55)';
      if (!this.element) return Promise.resolve();
      this.element.style.display = 'block';
      const keyframes = [{
        transform: 'translateY(-100px)',
        opacity: '0'
      }, {
        transform: 'translateY(0)',
        opacity: '1'
      }];
      const animation = this.element.animate(keyframes, {
        duration,
        easing,
        fill: 'forwards'
      });
      return animation.finished.then(() => {
        this.element.style.transform = 'translateY(0)';
        this.element.style.opacity = '1';
      });
    }

    /**
     * Bounce Out
     */
    bounceOut() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 600;
      let easing = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'easeInBounce';
      return this.custom({
        transform: 'translateY(0)',
        opacity: '1'
      }, {
        transform: 'translateY(-100px)',
        opacity: '0'
      }, duration, easing).then(() => {
        if (this.element) this.element.style.display = 'none';
      });
    }

    /**
     * Rotate In
     */
    rotateIn() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 400;
      let easing = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'easeOut';
      return this.custom({
        transform: 'rotate(-180deg) scale(0)',
        opacity: '0',
        display: 'block'
      }, {
        transform: 'rotate(0deg) scale(1)',
        opacity: '1'
      }, duration, easing);
    }

    /**
     * Rotate Out
     */
    rotateOut() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 400;
      let easing = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'easeIn';
      return this.custom({
        transform: 'rotate(0deg) scale(1)',
        opacity: '1'
      }, {
        transform: 'rotate(180deg) scale(0)',
        opacity: '0'
      }, duration, easing).then(() => {
        if (this.element) this.element.style.display = 'none';
      });
    }

    /**
     * Flip In
     */
    flipIn() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 600;
      let easing = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'easeOut';
      return this.custom({
        transform: 'perspective(400px) rotateY(90deg)',
        opacity: '0',
        display: 'block'
      }, {
        transform: 'perspective(400px) rotateY(0deg)',
        opacity: '1'
      }, duration, easing);
    }

    /**
     * Flip Out
     */
    flipOut() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 600;
      let easing = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'easeIn';
      return this.custom({
        transform: 'perspective(400px) rotateY(0deg)',
        opacity: '1'
      }, {
        transform: 'perspective(400px) rotateY(90deg)',
        opacity: '0'
      }, duration, easing).then(() => {
        if (this.element) this.element.style.display = 'none';
      });
    }

    /**
     * Shake
     */
    shake() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 500;
      if (!this.element) return Promise.resolve();
      const keyframes = [{
        transform: 'translateX(0)'
      }, {
        transform: 'translateX(-10px)'
      }, {
        transform: 'translateX(10px)'
      }, {
        transform: 'translateX(-10px)'
      }, {
        transform: 'translateX(10px)'
      }, {
        transform: 'translateX(-10px)'
      }, {
        transform: 'translateX(0)'
      }];
      return this.element.animate(keyframes, {
        duration,
        easing: 'ease-in-out'
      }).finished;
    }

    /**
     * Pulse
     */
    pulse() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 500;
      if (!this.element) return Promise.resolve();
      const keyframes = [{
        transform: 'scale(1)'
      }, {
        transform: 'scale(1.05)'
      }, {
        transform: 'scale(1)'
      }, {
        transform: 'scale(1.05)'
      }, {
        transform: 'scale(1)'
      }];
      return this.element.animate(keyframes, {
        duration,
        easing: 'ease-in-out'
      }).finished;
    }

    /**
     * Flash
     */
    flash() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 500;
      if (!this.element) return Promise.resolve();
      const keyframes = [{
        opacity: '1'
      }, {
        opacity: '0'
      }, {
        opacity: '1'
      }, {
        opacity: '0'
      }, {
        opacity: '1'
      }];
      return this.element.animate(keyframes, {
        duration,
        easing: 'ease-in-out'
      }).finished;
    }

    /**
     * Swing
     */
    swing() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 800;
      if (!this.element) return Promise.resolve();
      const keyframes = [{
        transform: 'rotate(0deg)'
      }, {
        transform: 'rotate(15deg)'
      }, {
        transform: 'rotate(-10deg)'
      }, {
        transform: 'rotate(5deg)'
      }, {
        transform: 'rotate(-5deg)'
      }, {
        transform: 'rotate(0deg)'
      }];
      return this.element.animate(keyframes, {
        duration,
        easing: 'ease-in-out'
      }).finished;
    }

    /**
     * Wobble
     */
    wobble() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 800;
      if (!this.element) return Promise.resolve();
      const keyframes = [{
        transform: 'translateX(0%) rotate(0deg)'
      }, {
        transform: 'translateX(-25%) rotate(-5deg)'
      }, {
        transform: 'translateX(20%) rotate(3deg)'
      }, {
        transform: 'translateX(-15%) rotate(-3deg)'
      }, {
        transform: 'translateX(10%) rotate(2deg)'
      }, {
        transform: 'translateX(-5%) rotate(-1deg)'
      }, {
        transform: 'translateX(0%) rotate(0deg)'
      }];
      return this.element.animate(keyframes, {
        duration,
        easing: 'ease-in-out'
      }).finished;
    }

    /**
     * Tada
     */
    tada() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 800;
      if (!this.element) return Promise.resolve();
      const keyframes = [{
        transform: 'scale(1) rotate(0deg)'
      }, {
        transform: 'scale(0.9) rotate(-3deg)'
      }, {
        transform: 'scale(0.9) rotate(-3deg)'
      }, {
        transform: 'scale(1.1) rotate(3deg)'
      }, {
        transform: 'scale(1.1) rotate(-3deg)'
      }, {
        transform: 'scale(1.1) rotate(3deg)'
      }, {
        transform: 'scale(1.1) rotate(-3deg)'
      }, {
        transform: 'scale(1.1) rotate(3deg)'
      }, {
        transform: 'scale(1.1) rotate(-3deg)'
      }, {
        transform: 'scale(1) rotate(0deg)'
      }];
      return this.element.animate(keyframes, {
        duration,
        easing: 'ease-in-out'
      }).finished;
    }

    /**
     * Heart Beat
     */
    heartBeat() {
      let duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1000;
      if (!this.element) return Promise.resolve();
      const keyframes = [{
        transform: 'scale(1)'
      }, {
        transform: 'scale(1.3)'
      }, {
        transform: 'scale(1)'
      }, {
        transform: 'scale(1.3)'
      }, {
        transform: 'scale(1)'
      }];
      return this.element.animate(keyframes, {
        duration,
        easing: 'ease-in-out'
      }).finished;
    }
  }

  /**
   * IMCAT UI Framework - Core Entry Point
   * @module imcat-ui
   * @version 1.0.0
   */


  /**
   * IMCAT Core Class
   * @class
   * @description IMCAT UI 프레임워크의 핵심 클래스입니다.
   * 모든 코어 모듈을 통합하고 전역 IMCAT 객체를 생성합니다.
   *
   * @example
   * const element = IMCAT('#app');
   * element.addClass('active').text('Hello');
   */
  class IMCATCore {
    /**
     * IMCATCore 생성자
     * @constructor
     */
    constructor() {
      // 싱글톤 인스턴스들
      this.eventBus = new EventBus();
      this.loader = new ModuleLoader();
      this.router = new ViewRouter();
      this.loadingIndicator = LoadingIndicator$1;

      // 이벤트 리스너 추적 (메모리 관리용)
      this._clickHandler = null;
      this._domReadyHandler = null;

      // Router에 Loading 통합 (URL 변경 없이 내부 렌더링만)
      this.router.init({
        loading: this.loadingIndicator,
        useHistory: false
      });

      // catui-href 자동 바인딩 (DOM ready 후)
      this._bindSPALinks();
    }

    /**
     * catui-href 자동 바인딩
     * SPA 링크를 자동으로 처리하여 설정 코드 불필요
     * @private
     */
    _bindSPALinks() {
      // DOM ready 핸들러
      const bindLinks = () => {
        // 기본 컨테이너 자동 감지
        this._detectRouterContainer();

        // 클릭 핸들러 생성 (나중에 제거할 수 있도록 저장)
        this._clickHandler = e => {
          // catui-href를 가진 요소 찾기
          const link = e.target.closest('[catui-href]');
          if (link) {
            // 이벤트 기본 동작 방지 (중복 네비게이션 방지)
            e.preventDefault();
            e.stopPropagation();
            const path = link.getAttribute('catui-href');
            const target = link.getAttribute('catui-target');
            if (path) {
              // 링크별 타겟이 있으면 임시로 변경
              const originalContainer = this.router.container;
              if (target) {
                this.router.setContainer(`#${target}`);
              }

              // 네비게이션 실행
              this.router.navigate(path).then(() => {
                // 원래 컨테이너로 복원 (타겟이 지정된 경우만)
                if (target) {
                  this.router.setContainer(originalContainer);
                }
              });
            }
          }
        };

        // capture 단계에서 이벤트 캡처 (더 일찍 처리)
        document.addEventListener('click', this._clickHandler, true);
      };

      // DOM이 이미 로드되었으면 즉시 실행, 아니면 대기
      if (document.readyState === 'loading') {
        this._domReadyHandler = bindLinks;
        document.addEventListener('DOMContentLoaded', this._domReadyHandler);
      } else {
        bindLinks();
      }
    }

    /**
     * Router 컨테이너 자동 감지
     * catui-target 속성 또는 기본 선택자 사용
     * @private
     */
    _detectRouterContainer() {
      // 1. catui-target 속성을 가진 요소 찾기
      const targetElement = document.querySelector('[catui-target]');
      if (targetElement) {
        const targetId = targetElement.getAttribute('catui-target');
        if (targetId) {
          this.router.setContainer(`#${targetId}`);
          return;
        }
      }

      // 2. 일반적인 선택자들 시도 (우선순위 순)
      const defaultSelectors = ['#app-content', '#content', '#app', 'main'];
      for (const selector of defaultSelectors) {
        if (document.querySelector(selector)) {
          this.router.setContainer(selector);
          return;
        }
      }

      // 3. 기본값
      this.router.setContainer('#content');
    }

    /**
     * DOM 요소 선택
     * @param {string|HTMLElement} selector - 선택자
     * @returns {DOMElement}
     */
    $(selector) {
      return DOM.select(selector);
    }

    /**
     * 새 요소 생성
     * @param {string} tagName - 태그 이름
     * @param {Object} attributes - 속성
     * @returns {DOMElement}
     */
    create(tagName, attributes) {
      return DOM.create(tagName, attributes);
    }

    /**
     * 모듈 로드
     * @param {...string} moduleNames - 모듈 이름들
     * @returns {Promise<*>}
     */
    use() {
      return this.loader.use(...arguments);
    }

    // ===== View Router API =====
    /**
     * View Router 인스턴스
     * @returns {ViewRouter}
     */
    get view() {
      return this.router;
    }

    // ===== API Utility =====
    /**
     * API 유틸리티
     * @returns {APIUtil}
     */
    get api() {
      return APIUtil;
    }

    // ===== Event Bus API =====
    /**
     * 이벤트 구독
     */
    on(event, handler) {
      return this.eventBus.on(event, handler);
    }

    /**
     * 일회성 이벤트 구독
     */
    once(event, handler) {
      return this.eventBus.once(event, handler);
    }

    /**
     * 이벤트 구독 취소
     */
    off(event, handler) {
      return this.eventBus.off(event, handler);
    }

    /**
     * 이벤트 발행
     */
    emit(event) {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      return this.eventBus.emit(event, ...args);
    }

    // ===== Loading Indicator API =====
    /**
     * Loading Indicator 인스턴스
     * @returns {LoadingIndicator}
     */
    get loading() {
      return this.loadingIndicator;
    }

    // ===== Template API =====
    /**
     * Template 엔진
     * @returns {Template}
     */
    get template() {
      return Template;
    }

    // ===== Storage API =====
    /**
     * Storage 유틸리티
     * @returns {Storage}
     */
    get storage() {
      return Storage;
    }

    // ===== URL API =====
    /**
     * URL 유틸리티
     * @returns {URLUtil}
     */
    get url() {
      return URLUtil;
    }

    // ===== State API =====
    /**
     * 상태 관리
     * @returns {StateManager}
     */
    get state() {
      return StateManager;
    }

    /**
     * 전역 상태
     * @returns {GlobalState}
     */
    get globalState() {
      return GlobalState;
    }

    // ===== Form API =====
    /**
     * 폼 검증
     * @returns {FormValidator}
     */
    get form() {
      return FormValidator;
    }

    // ===== Animation API =====
    /**
     * 애니메이션
     * @returns {AnimationUtil}
     */
    get animate() {
      return AnimationUtil.animate.bind(AnimationUtil);
    }

    /**
     * 애니메이션 유틸리티
     * @returns {AnimationUtil}
     */
    get animation() {
      return AnimationUtil;
    }

    // ===== Security API =====
    /**
     * HTML 이스케이프
     */
    escape(str) {
      return Security.escape(str);
    }

    /**
     * HTML 새니타이징
     */
    sanitize(html) {
      return Security.sanitize(html);
    }

    /**
     * 경로 검증
     */
    validatePath(path) {
      return Security.validatePath(path);
    }

    // ===== Utils API =====
    /**
     * 타입 체크 - 문자열
     */
    isString(value) {
      return Utils.isString(value);
    }

    /**
     * 타입 체크 - 숫자
     */
    isNumber(value) {
      return Utils.isNumber(value);
    }

    /**
     * 타입 체크 - 배열
     */
    isArray(value) {
      return Utils.isArray(value);
    }

    /**
     * 타입 체크 - 객체
     */
    isObject(value) {
      return Utils.isObject(value);
    }

    /**
     * 타입 체크 - 함수
     */
    isFunction(value) {
      return Utils.isFunction(value);
    }

    /**
     * 객체 병합
     */
    extend(target) {
      for (var _len2 = arguments.length, sources = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
        sources[_key2 - 1] = arguments[_key2];
      }
      return Utils.extend(target, ...sources);
    }

    /**
     * 깊은 복사
     */
    clone(obj) {
      return Utils.clone(obj);
    }

    /**
     * 디바운스
     */
    debounce(func, wait) {
      return Utils.debounce(func, wait);
    }

    /**
     * 스로틀
     */
    throttle(func, limit) {
      return Utils.throttle(func, limit);
    }

    /**
     * 랜덤 ID
     */
    randomId(prefix) {
      return Utils.randomId(prefix);
    }

    /**
     * DOM 준비 완료 시 실행
     */
    ready(callback) {
      return DOM.ready(callback);
    }

    /**
     * 버전 정보
     */
    get version() {
      return '1.0.0';
    }

    /**
     * 프레임워크 정리 (메모리 누수 방지)
     * SPA 재시작 또는 테스트 환경에서 사용
     *
     * @example
     * // 애플리케이션 종료 시
     * IMCAT.destroy();
     */
    destroy() {
      // 전역 클릭 리스너 제거 (capture 단계로 등록했으므로 같은 옵션으로 제거)
      if (this._clickHandler) {
        document.removeEventListener('click', this._clickHandler, true);
        this._clickHandler = null;
      }

      // DOMContentLoaded 리스너 제거 (아직 실행 안된 경우)
      if (this._domReadyHandler) {
        document.removeEventListener('DOMContentLoaded', this._domReadyHandler);
        this._domReadyHandler = null;
      }

      // 라우터 정리
      if (this.router && typeof this.router.destroy === 'function') {
        this.router.destroy();
      }

      // 이벤트 버스 정리
      if (this.eventBus && typeof this.eventBus.clear === 'function') {
        this.eventBus.clear();
      }

      // 모듈 로더 정리
      if (this.loader && typeof this.loader.destroy === 'function') {
        this.loader.destroy();
      }

      // 로딩 인디케이터 정리
      if (this.loadingIndicator && typeof this.loadingIndicator.destroy === 'function') {
        this.loadingIndicator.destroy();
      }
    }
  }

  // 전역 인스턴스 생성
  const IMCAT = new IMCATCore();

  // 전역 함수로도 사용 가능
  function IMCATFunction(selector) {
    return IMCAT.$(selector);
  }

  // IMCATCore의 프로토타입 메서드와 getter를 복사
  const proto = Object.getPrototypeOf(IMCAT);
  Object.getOwnPropertyNames(proto).forEach(key => {
    if (key === 'constructor') return;
    const descriptor = Object.getOwnPropertyDescriptor(proto, key);
    if (descriptor.get) {
      // getter인 경우
      Object.defineProperty(IMCATFunction, key, {
        get() {
          return IMCAT[key];
        }
      });
    } else if (typeof descriptor.value === 'function') {
      // 일반 메서드인 경우
      IMCATFunction[key] = IMCAT[key].bind(IMCAT);
    }
  });

  // 인스턴스 프로퍼티 복사
  Object.keys(IMCAT).forEach(key => {
    if (!Object.prototype.hasOwnProperty.call(IMCATFunction, key)) {
      Object.defineProperty(IMCATFunction, key, {
        get() {
          return IMCAT[key];
        }
      });
    }
  });

  // 브라우저 전역에 등록
  if (typeof window !== 'undefined') {
    window.IMCAT = IMCATFunction;
  }

  // Named exports는 모듈 개발자용
  // IIFE 빌드 시에는 default만 사용됨

  return IMCATFunction;

})();
